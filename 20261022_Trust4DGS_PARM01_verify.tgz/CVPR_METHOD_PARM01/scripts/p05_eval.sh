#!/bin/bash
# CVPR-METHOD-PARM01 stage 4: evaluation with the frozen metric identities.
#   A_NATIVE / E_EARLY_ONLY : frozen reference checkpoints (re-evaluated to prove
#                             the evaluator identity, not to change any number)
#   A0 / K / D              : the three PARM01 arms
set -u
cd "$(dirname "$0")"
source /home/star/IEEE/Trust4DGS/audit_SERVER_REGEN_SMOKE/g09f_cuda_env.sh >/dev/null 2>&1
export CUDA_VISIBLE_DEVICES=0
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=/home/star/miniconda3/envs/trust4dgs/bin/python
W=/home/star/IEEE/Trust4DGS
S=$W/CVPR_METHOD_PARM01
mkdir -p "$S/evals/Truck" "$S/logs"

A=$W/PAPER_CVPR_CORE01/runs/Truck_A/checkpoints/last.ckpt
E=$W/PAPER_CVPR_CORE01/runs/Truck_E/checkpoints/last.ckpt

for arm in A_NATIVE E_EARLY_ONLY A0 K D; do
  case $arm in
    A_NATIVE) C=$A ;;
    E_EARLY_ONLY) C=$E ;;
    *) C=$S/runs/Truck/$arm/checkpoints/last.ckpt ;;
  esac
  if [ ! -f "$C" ]; then echo "MISSING_CKPT $arm $C"; exit 3; fi
  echo "=== novel $arm $(date +%H:%M:%S) ==="
  $PY p06_eval.py --scene Truck --ckpt "$C" --arm "$arm" --mode novel \
      --outdir "$S/evals/Truck" > "$S/logs/eval_novel_$arm.log" 2>&1
  echo "novel $arm rc=$?"
  echo "=== train $arm $(date +%H:%M:%S) ==="
  $PY p06_eval.py --scene Truck --ckpt "$C" --arm "$arm" --mode train \
      --outdir "$S/evals/Truck" > "$S/logs/eval_train_$arm.log" 2>&1
  echo "train $arm rc=$?"
done

$PY p05b_identity.py > "$S/logs/eval_identity.log" 2>&1
echo "identity rc=$?"
grep -E "^(PASS|FAIL|PARM01_EVAL_IDENTITY)" "$S/logs/eval_identity.log"
echo "ALL_EVAL_DONE $(date -Is)"
