"""CVPR-METHOD-PARM01 deliverables: tables, paired statistics, gate label, report.

Nothing in this file can change a metric; it assembles and discloses.

Pre-declared stage-1 rule (fixed BEFORE any arm was trained, see
PARM01_PROTOCOL.json / parm_common.GATE):
    margin m = 0.02 dB, MAJOR_COST = 0.10 dB, cluster bootstrap (cluster = camera)
    95% CI, 4000 resamples, GAIN metrics = {bg_psnr, full_psnr}.

    gain      : exists f in GAIN with mean(D-K) >= m and CI_lo > 0
                (D must beat the CAPACITY-MATCHED plain residual, not just A0/E)
    fg_kept   : mean(D-A0).fg_psnr >= -m   (no material foreground loss vs native)
                and mean(D-K).fg_psnr >= -MAJOR_COST
    no_cost   : mean(D-K) >= -MAJOR_COST on band and halo, and
                D late_quarter_fg >= A0 late_quarter_fg - MAJOR_COST
    DISTINCT_REPRESENTATION_SIGNAL iff gain and fg_kept and no_cost
    CAPACITY_ONLY_GAIN iff not the above and K beats A0 on some f in GAIN with
                mean(K-A0) >= m and CI_lo > 0
    NO_ACTIONABLE_METHOD_GAIN otherwise
    Umbrella runs only if DISTINCT_REPRESENTATION_SIGNAL.

The label is a mechanical output.  It is a DEV signal, not a claim.
"""
import csv
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parm_common as K

S = K.S
ARMS = ("A_NATIVE", "E_EARLY_ONLY", "A0", "K", "D")
METRICS = ("full_psnr", "fg_psnr", "bg_psnr", "band_psnr", "halo_psnr")
LP = ("full_lpips", "fg_lpips", "bg_lpips", "band_lpips", "halo_lpips")
CONTRASTS = (("D", "K"), ("K", "A0"), ("D", "A0"), ("D", "E_EARLY_ONLY"),
             ("D", "A_NATIVE"), ("K", "A_NATIVE"), ("A0", "A_NATIVE"),
             ("D", "E_EARLY_ONLY"), ("K", "E_EARLY_ONLY"))
N_BOOT = K.GATE["bootstrap_n"]
MARGIN = K.GATE["margin_db"]
COST = K.GATE["major_cost_db"]
GAIN_METRICS = K.GATE["gain_metrics"]


def ev(scene, arm):
    return f"{S}/evals/{scene}/{arm}.json"


def train_ev(scene, arm):
    return f"{S}/evals/{scene}/train_{arm}.json"


def per_frame(arm):
    return {r["frame"]: r for r in json.load(open(ev(K.SCENE, arm)))["per_frame"]}


def camera_of(f):
    return f.split("_")[0]


def boot(d, cams, rng, n=N_BOOT):
    uc = np.unique(cams)
    idx = {c: np.where(cams == c)[0] for c in uc}
    bs = np.empty(n)
    for i in range(n):
        pick = rng.choice(uc, len(uc), replace=True)
        bs[i] = d[np.concatenate([idx[c] for c in pick])].mean()
    return float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))


def main():
    rng = np.random.default_rng(20261022)
    scene = K.SCENE
    summ, frames = {}, {}
    for arm in ARMS:
        summ[arm] = json.load(open(ev(scene, arm)))["summary"]
        summ[arm]["train"] = json.load(open(train_ev(scene, arm)))["summary"]
        frames[arm] = per_frame(arm)

    fl = sorted(frames["D"].keys())
    cams = np.array([camera_of(f) for f in fl])
    contrasts = []
    for x, y in CONTRASTS:
        for met in METRICS:
            d = np.array([frames[x][f][met] - frames[y][f][met] for f in fl])
            lo, hi = boot(d, cams, rng)
            contrasts.append({
                "contrast": f"{x}-{y}", "metric": met, "delta_db": float(d.mean()),
                "ci_lo": lo, "ci_hi": hi, "excludes_zero": bool(lo > 0 or hi < 0),
                "significant_gain": bool(lo > 0 and d.mean() >= MARGIN),
                "n_frames": len(fl), "n_clusters": int(len(np.unique(cams)))})
        for met in LP:
            d = np.array([frames[x][f][met] - frames[y][f][met] for f in fl])
            lo, hi = boot(d, cams, rng)
            contrasts.append({
                "contrast": f"{x}-{y}", "metric": met, "delta": float(d.mean()),
                "ci_lo": lo, "ci_hi": hi, "excludes_zero": bool(lo > 0 or hi < 0),
                "significant_gain": bool(hi < 0), "n_frames": len(fl),
                "n_clusters": int(len(np.unique(cams)))})

    C = {}
    for r in contrasts:
        C[(r["contrast"], r["metric"])] = r
    # CONTRASTS deliberately keeps its entries in the declared order; one pair is
    # listed twice, so the duplicate is dropped from the OUTPUT only, after every
    # bootstrap draw has already happened.  The reported intervals are therefore
    # bit-identical to the run made before this de-duplication.
    _seen, _dedup = set(), []
    for r in contrasts:
        key = (r["contrast"], r["metric"])
        if key in _seen:
            continue
        _seen.add(key)
        _dedup.append(r)
    contrasts = _dedup

    # ---------------------------------------------------------------- gate
    gains = []
    for met in GAIN_METRICS:
        r = C[("D-K", met)]
        gains.append({"metric": met, "delta_db": r["delta_db"], "ci_lo": r["ci_lo"],
                      "passes": bool(r["delta_db"] >= MARGIN and r["ci_lo"] > 0)})
    gain = any(g["passes"] for g in gains)
    fg_vs_a0 = C[("D-A0", "fg_psnr")]
    fg_vs_k = C[("D-K", "fg_psnr")]
    fg_kept = bool(fg_vs_a0["delta_db"] >= -MARGIN
                   and fg_vs_k["delta_db"] >= -COST)
    band = C[("D-K", "band_psnr")]
    halo = C[("D-K", "halo_psnr")]
    lq = {"D": summ["D"].get("late_quarter_fg_psnr"),
          "A0": summ["A0"].get("late_quarter_fg_psnr"),
          "K": summ["K"].get("late_quarter_fg_psnr")}
    no_cost = bool(band["delta_db"] >= -COST and halo["delta_db"] >= -COST
                   and lq["D"] >= lq["A0"] - COST)
    k_gains = []
    for met in GAIN_METRICS:
        r = C[("K-A0", met)]
        k_gains.append({"metric": met, "delta_db": r["delta_db"],
                        "ci_lo": r["ci_lo"],
                        "passes": bool(r["delta_db"] >= MARGIN and r["ci_lo"] > 0)})
    distinct = bool(gain and fg_kept and no_cost)
    capacity_only = bool((not distinct) and any(g["passes"] for g in k_gains))
    label = ("DISTINCT_REPRESENTATION_SIGNAL" if distinct else
             "CAPACITY_ONLY_GAIN" if capacity_only else
             "NO_ACTIONABLE_METHOD_GAIN")
    decision = {
        "rule": "pre-declared in PARM01_PROTOCOL.json before training",
        "margin_db": MARGIN, "major_cost_db": COST,
        "gain_metrics": list(GAIN_METRICS),
        "D_minus_K_gain_metrics": gains, "gain": gain,
        "fg_kept": {"D_minus_A0_fg_psnr": fg_vs_a0["delta_db"],
                    "D_minus_K_fg_psnr": fg_vs_k["delta_db"], "passes": fg_kept},
        "no_severe_cost": {"D_minus_K_band_psnr": band["delta_db"],
                           "D_minus_K_halo_psnr": halo["delta_db"],
                           "late_quarter_fg": lq, "passes": no_cost},
        "K_minus_A0_gain_metrics": k_gains,
        "label": label,
        "umbrella_umbrella_authorised": bool(distinct),
        "note": "mechanical output; DEV signal only, not a CVPR novelty claim",
    }

    # ------------------------------------------------------- results tables
    rows = []
    for arm in ARMS:
        s = summ[arm]
        st = s["train"]
        rows.append({
            "scene": scene, "arm": arm,
            "novel_full_psnr": s["novel_full_psnr"],
            "novel_full_lpips": s["novel_full_lpips"],
            "novel_fg_psnr": s["novel_fg_psnr"],
            "novel_fg_lpips": s["novel_fg_lpips"],
            "novel_bg_psnr": s["novel_bg_psnr"],
            "novel_bg_lpips": s["novel_bg_lpips"],
            "novel_band_psnr": s["novel_band_psnr"],
            "novel_band_lpips": s["novel_band_lpips"],
            "novel_halo_psnr": s["novel_halo_psnr"],
            "novel_halo_lpips": s["novel_halo_lpips"],
            "late_quarter_fg_psnr": s["late_quarter_fg_psnr"],
            "early_quarter_fg_psnr": s["early_quarter_fg_psnr"],
            "train_source_fg_psnr": st["train_source_fg_psnr"],
            "train_source_fg_lpips": st["train_source_fg_lpips"],
            "generalisation_gap_fg_psnr": (st["train_source_fg_psnr"]
                                           - s["novel_fg_psnr"]),
            "num_fg_gaussians": s["num_fg_gaussians"],
            "num_bg_gaussians": s["num_bg_gaussians"],
            "num_parameters": s.get("num_parameters", ""),
            "has_residual": s.get("has_residual", False),
            "n_residual_params": s.get("n_residual_params", 0),
            "eval_render_s_mean": s.get("render_s_mean", ""),
        })
    hdr = list(rows[0].keys())
    with open(f"{S}/PARM01_NATIVE_RECON_RESULTS.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=hdr)
        w.writeheader()
        w.writerows(rows)

    # -------------------------------------------- foreground/background time
    with open(f"{S}/PARM01_FOREGROUND_BACKGROUND_TEMPORAL.csv", "w",
              newline="") as f:
        w = csv.writer(f)
        w.writerow(["kind", "arm", "frame_or_bin", "time_id", "fg_psnr", "bg_psnr",
                    "band_psnr", "halo_psnr", "full_psnr", "fg_lpips", "bg_lpips"])
        for arm in ARMS:
            fr = json.load(open(ev(scene, arm)))["per_frame"]
            for r in sorted(fr, key=lambda r: r["val_index"]):
                w.writerow(["per_frame", arm, r["frame"], r["time_id"],
                            r["fg_psnr"], r["bg_psnr"], r["band_psnr"],
                            r["halo_psnr"], r["full_psnr"], r["fg_lpips"],
                            r["bg_lpips"]])
            for b in range(6):
                w.writerow(["temporal_bin", arm, f"bin{b} / 6", "",
                            summ[arm]["temporal_bins_fg_psnr"][b],
                            summ[arm]["temporal_bins_bg_psnr"][b],
                            summ[arm]["temporal_bins_band_psnr"][b], "",
                            summ[arm]["temporal_bins_full_psnr"][b], "", ""])

    with open(f"{S}/PARM01_CAPACITY_MATCHED_ABLATION.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["contrast", "metric", "delta", "ci_lo", "ci_hi",
                    "excludes_zero", "significant_gain", "margin_db",
                    "n_frames", "n_clusters"])
        for r in contrasts:
            w.writerow([r["contrast"], r["metric"], r["delta_db"] if "delta_db" in r
                        else r["delta"], r["ci_lo"], r["ci_hi"],
                        r["excludes_zero"], r["significant_gain"], MARGIN,
                        r["n_frames"], r["n_clusters"]])

    # ------------------------------------------------- trajectories and cost
    traj = {"step": "CVPR_METHOD_PARM01", "scene": scene,
            "frames": [0, 51, 102, 153, 203],
            "definition": "foreground displacement of the special Euclidean "
                          "transform applied to the canonical Gaussian means, "
                          "RMS over Gaussians, in scene units; prefix = the fork "
                          "state both arms started from", "arms": {}}
    tsel = torch.tensor(traj["frames"])
    state = {}
    for tag, path in (("PREFIX", f"{K.PREFIX_DIR}/checkpoints/last.ckpt"),
                      ("A0", f"{K.A0_DIR}/checkpoints/last.ckpt"),
                      ("K", f"{K.K_DIR}/checkpoints/last.ckpt"),
                      ("D", f"{K.D_DIR}/checkpoints/last.ckpt")):
        if not os.path.exists(path):
            continue
        ck = torch.load(path, map_location="cpu", weights_only=False)
        sd = ck["model"]
        coefs = torch.softmax(sd["fg.params.motion_coefs"], dim=-1)
        rots, trans = sd["motion_bases.params.rots"], sd["motion_bases.params.transls"]
        T = torch.einsum("pk,kni->pni", coefs, trans)[..., None]
        R = torch.einsum("pk,kni->pni", coefs, rots)
        from flow3d.transforms import cont_6d_to_rmat
        Tb = torch.cat([cont_6d_to_rmat(R), T], dim=-1)[:, tsel]
        resid = {k[len("parm_resid."):]: v for k, v in sd.items()
                 if k.startswith("parm_resid.")}
        state[tag] = {"T": Tb, "means": sd["fg.params.means"], "resid": resid,
                      "num_frames": int(trans.shape[1])}

    def pos(T, m):
        return torch.einsum("pnij,pj->pni", T, torch.nn.functional.pad(
            m, (0, 1), value=1.0))

    p_pref = pos(state["PREFIX"]["T"], state["PREFIX"]["means"])
    for tag in ("A0", "K", "D"):
        if tag not in state:
            continue
        rec = {}
        p = pos(state[tag]["T"], state[tag]["means"])
        rec["base_motion_drift_vs_prefix_rms"] = [
            float((p[:, i] - p_pref[:, i]).norm(dim=-1).pow(2).mean().sqrt())
            for i in range(len(tsel))]
        rec["canonical_mean_drift_vs_prefix_rms"] = [
            float((state[tag]["means"] - state["PREFIX"]["means"]).norm(dim=-1)
                  .pow(2).mean().sqrt())] * len(tsel)
        if "coef" in state[tag]["resid"]:
            res = K.ResidualMotion(state[tag]["means"].shape[0],
                                   state[tag]["num_frames"], K.RESID["R"])
            res.load_state_dict(state[tag]["resid"])
            with torch.no_grad():
                Tr = res.transforms(tsel)
                pc = pos(K.compose(state[tag]["T"], Tr), state[tag]["means"])
                rec["residual_displacement_rms"] = [
                    float((pc[:, i] - p[:, i]).norm(dim=-1).pow(2).mean().sqrt())
                    for i in range(len(tsel))]
                rec["residual_rot_angle_rad_mean"] = [
                    float(torch.acos((((Tr[:, i, :3, :3].diagonal(dim1=-2, dim2=-1)
                                        .sum(-1)) - 1.0) / 2.0).clamp(-1.0, 1.0))
                          .mean())
                    for i in range(len(tsel))]
                rec["residual_coef_abs_mean"] = float(res.coef.abs().mean())
                rec["residual_coef_abs_max"] = float(res.coef.abs().max())
                rec["residual_coef_frac_nonzero"] = float(
                    (res.coef.abs() > 1e-8).float().mean())
                rec["residual_basis_abs_mean"] = float(res.basis.abs().mean())
        traj["arms"][tag] = rec

    cost = {"step": "CVPR_METHOD_PARM01", "budget_gpu_hours": 4.0,
            "scenes": [scene], "arms": {}, "assets": {}}
    for tag, d in (("PREFIX", K.PREFIX_DIR), ("A0", K.A0_DIR), ("K", K.K_DIR),
                   ("D", K.D_DIR)):
        p = f"{d}/run.json"
        if not os.path.exists(p):
            continue
        r = json.load(open(p))
        cost["arms"][tag] = {
            "wall_train_s": r.get("wall_train_s", r.get("wall_s")),
            "updates": r.get("steps_done", r.get("updates_done")),
            "s_per_update": r.get("mean_s_per_step", r.get("s_per_update_mean")),
            "peak_vram_gib": r.get("peak_vram_gib"),
            "ckpt_path": r.get("ckpt_path", f"{d}/checkpoints/last.ckpt"),
            "ckpt_sha256": r.get("ckpt_sha256"),
            "global_step_end": r.get("gs1"),
        }
    ev_cost = {}
    for arm in ARMS:
        s = summ[arm]
        ev_cost[arm] = {"render_s_mean_novel": s.get("render_s_mean"),
                        "render_s_total_novel": s.get("render_s_total"),
                        "model_load_s": s.get("model_load_s"),
                        "num_parameters": s.get("num_parameters"),
                        "n_residual_params": s.get("n_residual_params")}
    cost["evals"] = ev_cost
    gpu_total = sum((v.get("wall_train_s") or 0) for v in cost["arms"].values())
    cost["gpu_active_hours_train"] = gpu_total / 3600.0
    cost["gpu_active_hours_total_with_eval_estimate"] = (
        gpu_total + 600.0) / 3600.0
    # decision / trajectory / summaries are written BEFORE hashing, so that every
    # artifact of this step is covered by the manifest below.
    K.jdump(decision, f"{S}/PARM01_STAGE1_DECISION.json")
    K.jdump(traj, f"{S}/PARM01_TRAJECTORY_AUDIT.json")
    K.jdump(summ, f"{S}/PARM01_EVAL_SUMMARIES.json")
    cost["sha256"] = {
        p: K.sha256_file(p) for p in (
            f"{S}/PARM01_PROTOCOL.json",
            f"{S}/PARM01_METHOD_IDENTITY.json",
            f"{S}/PARM01_GRADIENT_SEPARATION_AUDIT.json",
            f"{S}/PARM01_PREFLIGHT_GATE.json",
            f"{S}/PARM01_GATE_AND_METRICS.json",
            f"{S}/PARM01_NATIVE_RECON_RESULTS.csv",
            f"{S}/PARM01_FOREGROUND_BACKGROUND_TEMPORAL.csv",
            f"{S}/PARM01_CAPACITY_MATCHED_ABLATION.csv",
            f"{S}/PARM01_EVALUATOR_IDENTITY.json",
            f"{S}/PARM01_STAGE1_DECISION.json",
            f"{S}/PARM01_TRAJECTORY_AUDIT.json",
            f"{S}/PARM01_EVAL_SUMMARIES.json",
            f"{S}/scripts/parm_common.py",
            f"{S}/scripts/p01_preflight.py",
            f"{S}/scripts/p02_gate.py",
            f"{S}/scripts/p03_run_all.sh",
            f"{S}/scripts/p04_train.py",
            f"{S}/scripts/p05_eval.sh",
            f"{S}/scripts/p05b_identity.py",
            f"{S}/scripts/p06_eval.py",
            f"{S}/scripts/p07_deliver.py",
            f"{S}/scripts/p08_report.py",
        ) if os.path.exists(p)}
    cost["evals_sha256"] = {
        p: K.sha256_file(p) for p in sorted(
            [f"{S}/evals/{scene}/{a}.json" for a in ARMS]
            + [f"{S}/evals/{scene}/train_{a}.json" for a in ARMS])}
    cost["self_excluded"] = (
        "PARM01_COST_AND_SHA256.json cannot hash itself; PARM01_EXECUTION_REPORT.md "
        "and PARM01_SOURCE_DIFF.md are written after this file, and p08_report.py "
        "appends their hashes under `sha256_after_report`.")
    cost["frozen_inputs_sha256"] = {
        p: K.sha256_file(p) for p in (
            K.INIT_CKPT, K.FROZEN_A_CKPT, K.FROZEN_E_CKPT, K.PS_STAGE) }

    K.jdump(cost, f"{S}/PARM01_COST_AND_SHA256.json")
    print("PARM01_DELIVER " + json.dumps(
        {"label": label, "gain": gain, "fg_kept": fg_kept, "no_cost": no_cost,
         "D_minus_K_full": C[("D-K", "full_psnr")]["delta_db"],
         "D_minus_K_bg": C[("D-K", "bg_psnr")]["delta_db"],
         "K_minus_A0_full": C[("K-A0", "full_psnr")]["delta_db"]}), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
