"""CVPR-METHOD-PARM01 shared core: Prior-Anchored Residual Motion (PARM).

ENGINEERING ONLY.  Nothing frozen is modified:
  * flow3d / SoM source (scene_model.py, params.py, trainer.py, loss_utils.py)
  * frozen evaluators (ps02_eval.py, pc_eval_train.py), cape_common.py, m1_eval.py
  * frozen checkpoints, main table, train/val splits
Everything new lives in this file and this step directory.

WHAT THE METHOD IS (locked before any result is read)
  Native SoM renders the foreground at time t through
      T_base(t) = T( sum_k softmax(coef_p)_k * B_k(t) )       (K=10 bases, T=204)
  where B_k(t) = (cont6d rotation, translation).

  PARM adds a low-capacity, time-parameterised residual rigid motion in the
  canonical frame, composed on the RIGHT (spec: T_render = T_prior o Exp(delta)):

      delta_p(t) = sum_r a_{p,r} * xi_r(t)          xi in se(3), r = 1..R
      Delta_p(t) = Exp(delta_p(t))                  (SE(3) exponential map)
      T_render(t) = T_base(t) @ Delta_p(t)

  a_{p,r} is initialised EXACTLY zero with no softmax, hence Delta = Identity at
  initialisation and the initial render is bit-identical to the frozen model
  (verified, not assumed: p01 CPU gate and p02 GPU gate).

  Locked capacity (declared before any training, never revisited):
      R = 4 residual bases
      parm_resid.coef  : (G_fg, R)     init 0
      parm_resid.basis : (R, T, 6)     se(3) twists, N(0, 0.02^2), seed 20261022
      lr(coef)  = 1e-2    (native fg.motion_coefs lr)
      lr(basis) = 1.6e-4  (native motion_bases lr)
      reg: 1e-3 * mean(a^2)  +  0.1 * (se(3) temporal accel of xi)
  The SAME module, init, lr and regulariser are used by K and D, so none of these
  constants can confound the D-vs-K contrast.

THREE ARMS FROM ONE FORK (Truck, native global_step 4000)
  A0 : frozen native trainer (ps_stage.py --arm A), prior ON, no residual.
  K  : same native objective in ONE graph, T = T_base @ Delta; prior losses
       (depth/track) and RGB/mask both act on the composed motion.  This is the
       capacity-matched plain-residual baseline that D must beat.
  D  : identical capacity/init/lr/reg/length to K.  Gradient routing separated at
       the level of the COMPUTATION GRAPH (not by requires_grad flags):
         pass 1 (prior): geometry from T_base ONLY (residual absent from the
                graph), all appearance tensors detached -> depth/track can only
                reach fg.params.motion_coefs and motion_bases.params.{rots,transls}
         pass 2 (photometric): geometry from T_base.detach() @ Delta, appearance
                live -> RGB/mask can only reach the residual and the native
                appearance parameters; they cannot reach the base motion.

  Camera / topology / time identity are inherited: the fork is at global_step
  4000, where native density control has already stopped (stop_control_steps =
  4000), so topology cannot change in any arm; camera parameters are frozen
  exactly as in the SRR01/ADV01 continuation protocol.
"""
import hashlib
import json
import os
import sys

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

W = "/home/star/IEEE/Trust4DGS"
S = f"{W}/CVPR_METHOD_PARM01"
M1 = f"{W}/METHOD01_CAPE4D"
ROUTE = f"{W}/PAPER_CVPR_CORE01/scripts/frozen_source"
for p in (f"{M1}/scripts",
          f"{W}/Trust4DGS_Portable/RouteA_Transfer/repo",
          f"{W}/Trust4DGS_Portable/RouteA_Transfer/repo/third_party/shape_of_motion",
          ROUTE):
    if p not in sys.path:
        sys.path.insert(0, p)

import cape_common as C          # noqa: E402  frozen identity (datasets)
import roma                      # noqa: E402
from flow3d.loss_utils import (  # noqa: E402
    compute_gradient_loss as _grad_loss,
    compute_se3_smoothness_loss as _se3_smooth,
    compute_z_acc_loss as _z_acc,
    masked_l1_loss as _masked_l1,
)
from pytorch_msssim import SSIM  # noqa: E402  same ctor args as frozen Trainer

SCENE = "Truck"
FORK_STEP = 4000
TOTAL_STEPS = 13000
N_STEPS = TOTAL_STEPS - FORK_STEP        # 9000 continuation updates per arm
BATCH = 8
SEED = 42

ARMS = ("A0", "K", "D")
REF_ARMS = ("A_NATIVE", "E_EARLY_ONLY")

PREFIX_DIR = f"{S}/runs/{SCENE}/PREFIX"
A0_DIR = f"{S}/runs/{SCENE}/A0"
K_DIR = f"{S}/runs/{SCENE}/K"
D_DIR = f"{S}/runs/{SCENE}/D"
ARM_DIRS = {"A0": A0_DIR, "K": K_DIR, "D": D_DIR}

INIT_CKPT = f"{W}/R2_A01/base/Truck/checkpoints/init.ckpt"
FROZEN_A_CKPT = f"{W}/PAPER_CVPR_CORE01/runs/Truck_A/checkpoints/last.ckpt"
FROZEN_E_CKPT = f"{W}/PAPER_CVPR_CORE01/runs/Truck_E/checkpoints/last.ckpt"
FROZEN_A_EVAL = f"{W}/PAPER_CVPR_CORE01/evals/Truck/A_NATIVE.json"
FROZEN_E_EVAL = f"{W}/PAPER_CVPR_CORE01/evals/Truck/E_EARLY_ONLY.json"

PS_STAGE = f"{ROUTE}/ps_stage.py"

# native loss weights at the fork (LossesConfig() defaults; prior regime A)
NATIVE_W = {
    "w_rgb": 1.0, "w_mask": 1.0, "w_smooth_bases": 0.1, "w_scale_var": 0.01,
    "w_z_accel": 1.0, "w_depth_reg": 0.5, "w_depth_const": 0.1,
    "w_depth_grad": 1.0, "w_track": 2.0, "w_smooth_tracks": 2.0,
}
W_OF = {"rgb": "w_rgb", "mask": "w_mask", "scale_var": "w_scale_var",
        "scale_var_bg": "w_scale_var",
        "depth_reg": "w_depth_reg", "depth_const": "w_depth_const",
        "depth_grad": "w_depth_grad", "track": "w_track",
        "smooth_tracks": "w_smooth_tracks", "smooth_bases": "w_smooth_bases",
        "z_accel": "w_z_accel"}
# frozen summation order of Trainer.compute_losses (rgb -> mask -> track ->
# depth_reg -> depth_const -> depth_grad -> smooth_bases -> smooth_tracks ->
# scale_var -> z_accel); kept so that A0-mode totals are bitwise comparable.
SUM_ORDER = ("rgb", "mask", "track", "depth_reg", "depth_const", "depth_grad",
             "smooth_bases", "smooth_tracks", "scale_var", "scale_var_bg",
             "z_accel")

PRIOR_TERMS = ("depth_reg", "depth_const", "depth_grad", "track",
               "smooth_tracks", "smooth_bases", "z_accel")
PHOTO_TERMS = ("rgb", "mask", "scale_var")
ALL_TERMS = PHOTO_TERMS + PRIOR_TERMS

BASE_MOTION = ("fg.params.motion_coefs", "motion_bases.params.rots",
               "motion_bases.params.transls")
APPEARANCE = ("fg.params.colors", "fg.params.means", "fg.params.scales",
              "fg.params.quats", "fg.params.opacities", "bg.params.colors",
              "bg.params.means", "bg.params.scales", "bg.params.quats",
              "bg.params.opacities")
RESID_PARAMS = ("parm_resid.coef", "parm_resid.basis")

RESID = {
    "R": 4, "basis_init_sigma": 0.02, "init_seed": 20261022,
    "lr_coef": 1e-2, "lr_basis": 1.6e-4,
    "w_res_l2": 1e-3, "w_res_smooth": 0.1,
    "composition": "T_render = T_base @ Exp(sum_r a_r xi_r(t)) (right compose)",
    "coef_init": "exactly zero, no softmax -> Delta = I at init",
}

# pre-declared stage-1 gate (Truck only), fixed BEFORE any arm is trained
GATE = {
    "margin_db": 0.02, "major_cost_db": 0.10, "bootstrap_n": 4000,
    "cluster": "camera (frame name prefix before '_')", "ci": 0.95,
    "gain_metrics": ("bg_psnr", "full_psnr"),
    "declared": "2026-10-22, before any PARM01 arm was trained",
}

_SSIM = SSIM(data_range=1.0, size_average=True, channel=3)


# --------------------------------------------------------------------- helpers
def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def jdump(obj, p):
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    with open(p, "w") as f:
        json.dump(obj, f, indent=1, default=float)


def jload(p):
    with open(p) as f:
        return json.load(f)


def set_seed(seed=SEED):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def data_dir():
    return C.data_dir(SCENE)


def load_train_ds():
    from flow3d.data import get_train_val_datasets, NvidiaDataConfig
    ds, _, _, _ = get_train_val_datasets(
        NvidiaDataConfig(data_dir=data_dir(), load_from_cache=True), load_val=False)
    return ds


def make_loader(ds):
    """The frozen native loader: sequential, no shuffle, num_workers=0
    (identical to ps_stage.py so every arm sees the same batch sequence)."""
    from flow3d.data import BaseDataset
    from torch.utils.data import DataLoader
    return DataLoader(ds, batch_size=BATCH, num_workers=0,
                      collate_fn=BaseDataset.train_collate_fn)


def param_class(name):
    if name in RESID_PARAMS:
        return "resid"
    if name in BASE_MOTION:
        return "base_motion"
    if name in APPEARANCE:
        return "appearance" if name.startswith("fg.") else "appearance_bg"
    if name.startswith("camera_poses."):
        return "camera"
    return "other"


# ------------------------------------------------------------ residual motion
def _so3_hat(w):
    z = torch.zeros_like(w[..., 0])
    return torch.stack([
        torch.stack([z, -w[..., 2], w[..., 1]], -1),
        torch.stack([w[..., 2], z, -w[..., 0]], -1),
        torch.stack([-w[..., 1], w[..., 0], z], -1)], -2)


def se3_exp(xi):
    """xi (..., 6) = (omega, nu) -> (R (...,3,3), t (...,3)).  Exact at xi = 0."""
    w, v = xi[..., :3], xi[..., 3:]
    th2 = (w * w).sum(-1, keepdim=True)
    th = torch.sqrt(th2.clamp_min(1e-20))
    small = th2 < 1e-8
    ths = torch.where(small, torch.ones_like(th), th)
    a = torch.where(small, 1.0 - th2 / 6.0, torch.sin(ths) / ths)
    b = torch.where(small, 0.5 - th2 / 24.0, (1.0 - torch.cos(ths)) / ths ** 2)
    c = torch.where(small, 1.0 / 6.0 - th2 / 120.0,
                    (ths - torch.sin(ths)) / ths ** 3)
    Wx = _so3_hat(w)
    Wx2 = Wx @ Wx
    eye = torch.eye(3, device=xi.device, dtype=xi.dtype).expand_as(Wx)
    R = eye + a.unsqueeze(-1) * Wx + b.unsqueeze(-1) * Wx2
    V = eye + b.unsqueeze(-1) * Wx + c.unsqueeze(-1) * Wx2
    t = (V @ v.unsqueeze(-1)).squeeze(-1)
    return R, t


class ResidualMotion(nn.Module):
    """Fixed small-capacity time-parameterised residual rigid motion.

    coef (G, R) is exactly zero at init and NOT softmaxed, so the residual is
    exactly the identity at initialisation whatever the basis holds.
    """

    def __init__(self, G, T, R, sigma=None, seed=None):
        super().__init__()
        sigma = RESID["basis_init_sigma"] if sigma is None else sigma
        seed = RESID["init_seed"] if seed is None else seed
        self.num_gaussians = int(G)
        self.num_frames = int(T)
        self.num_bases = int(R)
        gen = torch.Generator(device="cpu").manual_seed(int(seed))
        basis = torch.randn(int(R), int(T), 6, generator=gen) * float(sigma)
        self.coef = nn.Parameter(torch.zeros(int(G), int(R)))
        self.basis = nn.Parameter(basis)

    def twists(self, ts):
        """ts (B,) -> xi (G, B, 6)."""
        return torch.einsum("gr,rbk->gbk", self.coef, self.basis[:, ts, :])

    def transforms(self, ts):
        """ts (B,) -> (G, B, 3, 4)."""
        R, t = se3_exp(self.twists(ts))
        return torch.cat([R, t[..., None]], dim=-1)

    def n_params(self):
        return int(self.coef.numel() + self.basis.numel())

    def regularizer(self):
        l2 = (self.coef ** 2).mean()
        xi = self.basis
        accel = 2 * xi[:, 1:-1] - xi[:, :-2] - xi[:, 2:]
        smooth = accel.norm(dim=-1).mean()
        return (RESID["w_res_l2"] * l2 + RESID["w_res_smooth"] * smooth,
                {"res_l2": float(l2.detach()), "res_smooth": float(smooth.detach())})


def compose(T_base, T_res):
    """T_base (...,3,4) @ T_res (...,3,4) -> (...,3,4)."""
    Rb, tb = T_base[..., :3, :3], T_base[..., :3, 3]
    Rr, tr = T_res[..., :3, :3], T_res[..., :3, 3]
    R = Rb @ Rr
    t = (Rb @ tr[..., None]).squeeze(-1) + tb
    return torch.cat([R, t[..., None]], dim=-1)


# --------------------------------------------------------------- pose helpers
def pose_from_transforms(model, T, detach_canonical=False):
    """(G,B,3,4) -> means (G,B,3), quats (G,B,4); frozen op order (bitwise)."""
    means = model.fg.params["means"]
    quats = model.fg.get_quats()
    if detach_canonical:
        means, quats = means.detach(), quats.detach()
    m = torch.einsum("pnij,pj->pni", T, F.pad(means, (0, 1), value=1.0))
    q = roma.quat_xyzw_to_wxyz(
        roma.quat_product(roma.rotmat_to_unitquat(T[..., :3, :3]),
                          roma.quat_wxyz_to_xyzw(quats[:, None])))
    q = F.normalize(q, p=2, dim=-1)
    if model.bg is not None:
        bm, bq = model.bg.params["means"], model.bg.get_quats()
        if detach_canonical:
            bm, bq = bm.detach(), bq.detach()
        m = torch.cat([m, bm[:, None].expand(-1, m.shape[1], -1)], 0).contiguous()
        q = torch.cat([q, bq[:, None].expand(-1, q.shape[1], -1)], 0).contiguous()
    return m, q


def base_transforms(model, ts):
    coefs = model.fg.get_coefs()                       # (G,K) softmax
    return model.motion_bases.compute_transforms(ts, coefs)


def _geom(model, T_main, T_tgt, batch, detach_canonical=False):
    N = batch["target_ts"][0].shape[0]
    means, quats = pose_from_transforms(model, T_main, detach_canonical)
    tm, _ = pose_from_transforms(model, T_tgt, detach_canonical)
    tm = tm.transpose(0, 1)                            # (B*N, G, 3)
    return {"means": means.transpose(0, 1),            # (B, G, 3)
            "quats": quats.transpose(0, 1),            # (B, G, 4)
            "target_means": [x.transpose(0, 1) for x in tm.split(N)]}


def geom_A0(model, batch):
    """Frozen pose path (no residual); used for the identity audit."""
    ts = batch["ts"]
    means, quats = model.compute_poses_all(ts)
    N = batch["target_ts"][0].shape[0]
    tm, _ = model.compute_poses_all(torch.cat(batch["target_ts"]))
    tm = tm.transpose(0, 1)
    return {"means": means.transpose(0, 1), "quats": quats.transpose(0, 1),
            "target_means": [x.transpose(0, 1) for x in tm.split(N)]}


def geom_K(model, res, batch):
    ts, tvec = batch["ts"], torch.cat(batch["target_ts"])
    T = compose(base_transforms(model, ts), res.transforms(ts))
    Tt = compose(base_transforms(model, tvec), res.transforms(tvec))
    return _geom(model, T, Tt, batch)


def geom_D_prior(model, batch):
    """Base motion ONLY (residual absent from the graph), appearance detached."""
    ts, tvec = batch["ts"], torch.cat(batch["target_ts"])
    return _geom(model, base_transforms(model, ts),
                 base_transforms(model, tvec), batch, detach_canonical=True)


def geom_D_photo(model, res, batch):
    """Base motion DETACHED, residual + appearance live."""
    ts, tvec = batch["ts"], torch.cat(batch["target_ts"])
    T = compose(base_transforms(model, ts).detach(), res.transforms(ts))
    Tt = compose(base_transforms(model, tvec).detach(), res.transforms(tvec))
    return _geom(model, T, Tt, batch)


# -------------------------------------------------- frozen-parity loss terms
def compute_terms(model, batch, geom, need):
    """Raw (UNWEIGHTED) native loss terms, verbatim from Trainer.compute_losses.

    The ONLY deviation from the frozen source: foreground/bg poses are supplied
    by `geom` instead of being recomputed from live parameters in-place.  Same
    render calls and order, same masks, same quantiles, same normalisation.
    """
    B = batch["imgs"].shape[0]
    W, H = img_wh = batch["imgs"].shape[2:0:-1]
    N = batch["target_ts"][0].shape[0]
    ts = batch["ts"]
    w2cs = batch["w2cs"]
    Ks = batch["Ks"]
    imgs = batch["imgs"]
    valid_masks = batch.get("valid_masks", torch.ones_like(batch["imgs"][..., 0]))
    masks = batch["masks"] * valid_masks          # values identical to frozen
    depths = batch["depths"]
    query_tracks_2d = batch["query_tracks_2d"]
    target_ts = batch["target_ts"]
    target_w2cs = batch["target_w2cs"]
    target_Ks = batch["target_Ks"]
    target_tracks_2d = batch["target_tracks_2d"]
    target_visibles = batch["target_visibles"]
    target_confidences = batch["target_confidences"]
    target_track_depths = batch["target_track_depths"]

    means, quats = geom["means"], geom["quats"]
    device = means.device
    need_depth = ("depth_reg" in need) or ("depth_grad" in need)
    need_track = ("track" in need) or ("depth_const" in need)

    rendered_all, bg_colors = [], []
    for i in range(B):
        bg_color = torch.ones(1, 3, device=device)
        rendered = model.render(
            ts[i].item(), w2cs[None, i], Ks[None, i], img_wh,
            target_ts=target_ts[i] if need_track else None,
            target_w2cs=target_w2cs[i] if need_track else None,
            bg_color=bg_color, means=means[i], quats=quats[i],
            target_means=geom["target_means"][i] if need_track else None,
            return_depth=need_depth, return_mask=model.has_bg)
        rendered_all.append(rendered)
        bg_colors.append(bg_color)
    rendered_all = {
        key: (torch.cat([d[key] for d in rendered_all], dim=0)
              if rendered_all[0][key] is not None else None)
        for key in rendered_all[0]}
    bg_colors = torch.cat(bg_colors, dim=0)

    target_ts_vec = torch.cat(target_ts)
    frame_intervals = (ts.repeat_interleave(N) - target_ts_vec).abs()
    if not model.has_bg:
        imgs_l = (imgs * masks[..., None]
                  + (1.0 - masks[..., None]) * bg_colors[:, None, None])
    else:
        imgs_l = (imgs * valid_masks[..., None]
                  + (1.0 - valid_masks[..., None]) * bg_colors[:, None, None])

    out = {}
    if "rgb" in need:
        rendered_imgs = rendered_all["img"]
        if model.has_bg:
            rendered_imgs = (rendered_imgs * valid_masks[..., None]
                             + (1.0 - valid_masks[..., None]) * bg_colors[:, None, None])
        out["rgb"] = 0.8 * F.l1_loss(rendered_imgs, imgs_l) + 0.2 * (
            1 - _SSIM(rendered_imgs.permute(0, 3, 1, 2),
                      imgs_l.permute(0, 3, 1, 2)))

    if "mask" in need:
        if not model.has_bg:
            out["mask"] = F.mse_loss(rendered_all["acc"], masks[..., None])
        else:
            out["mask"] = F.mse_loss(
                rendered_all["acc"], torch.ones_like(rendered_all["acc"])) + \
                _masked_l1(rendered_all["mask"], masks[..., None], quantile=0.98)

    masks_flatten = torch.zeros_like(masks)
    for i in range(B):
        qp = query_tracks_2d[i].to(torch.int64)
        masks_flatten[i, qp[:, 1], qp[:, 0]] = 1.0
    masks_flatten = (masks_flatten.reshape(-1, H * W).tile(1, N)
                     .reshape(-1, H * W) > 0.5)

    track_weights = visibles = mapped_depth = None
    if need_track:
        tracks_2d = torch.cat([x.reshape(-1, 2) for x in target_tracks_2d], dim=0)
        visibles = torch.cat([x.reshape(-1) for x in target_visibles], dim=0)
        confidences = torch.cat([x.reshape(-1) for x in target_confidences], dim=0)
        pred_tracks_3d = rendered_all["tracks_3d"].permute(
            0, 3, 1, 2, 4).reshape(-1, H * W, 3)
        pred_tracks_2d = torch.einsum("bij,bpj->bpi", torch.cat(target_Ks),
                                      pred_tracks_3d)
        mapped_depth = torch.clamp(pred_tracks_2d[..., 2:], min=1e-6)
        pred_tracks_2d = pred_tracks_2d[..., :2] / mapped_depth
        w_interval = torch.exp(-2 * frame_intervals / model.num_frames)
        track_weights = confidences[..., None] * w_interval
        if "track" in need:
            out["track"] = _masked_l1(
                pred_tracks_2d[masks_flatten][visibles], tracks_2d[visibles],
                mask=track_weights[visibles], quantile=0.98) / max(H, W)

    depth_masks = masks[..., None] if not model.has_bg else valid_masks[..., None]
    if need_depth:
        pred_depth = rendered_all["depth"]
        pred_disp = 1.0 / (pred_depth + 1e-5)
        tgt_disp = 1.0 / (depths[..., None] + 1e-5)
        if "depth_reg" in need:
            out["depth_reg"] = _masked_l1(pred_disp, tgt_disp, mask=depth_masks,
                                          quantile=0.98)
        if "depth_grad" in need:
            out["depth_grad"] = _grad_loss(pred_disp, tgt_disp,
                                           mask=depth_masks > 0.5, quantile=0.95)
    if "depth_const" in need:
        md_gt = torch.cat([x.reshape(-1) for x in target_track_depths], dim=0)
        out["depth_const"] = _masked_l1(
            1 / (mapped_depth[masks_flatten][visibles] + 1e-5),
            1 / (md_gt[visibles, None] + 1e-5), track_weights[visibles])

    if "smooth_bases" in need:
        out["smooth_bases"] = _se3_smooth(
            model.motion_bases.params["rots"], model.motion_bases.params["transls"])

    if ("smooth_tracks" in need) or ("z_accel" in need):
        ts_c = torch.clamp(ts, min=1, max=model.num_frames - 2)
        nbs = torch.cat((ts_c - 1, ts_c, ts_c + 1))
        Tn = base_transforms(model, nbs)
        mfg = torch.einsum("pnij,pj->pni", Tn,
                           F.pad(model.fg.params["means"], (0, 1), value=1.0))
        mfg = mfg.reshape(mfg.shape[0], 3, -1, 3)
        if "smooth_tracks" in need:
            out["smooth_tracks"] = 0.5 * (
                (2 * mfg[:, 1:-1] - mfg[:, :-2] - mfg[:, 2:]).norm(dim=-1).mean())
        if "z_accel" in need:
            out["z_accel"] = _z_acc(mfg, w2cs)

    if "scale_var" in need:
        # kept as two separate terms so that the weighted sum reproduces the
        # frozen `loss += w*var_fg` / `loss += w*var_bg` rounding exactly
        out["scale_var"] = torch.var(torch.exp(model.fg.params["scales"]),
                                     dim=-1).mean()
        if model.bg is not None:
            out["scale_var_bg"] = torch.var(torch.exp(model.bg.params["scales"]),
                                            dim=-1).mean()
    return out


def weighted_total(terms, extra=None):
    """Sum weighted terms in the frozen order (+ optional extra loss tensor)."""
    total = 0.0
    for k in SUM_ORDER:
        if k in terms:
            total = total + NATIVE_W[W_OF[k]] * terms[k]
    if extra is not None:
        total = total + extra
    return total


# --------------------------------------------------- structural parameter masks
class freeze_params:
    """Replace parameters by detached, non-trainable clones for a code region.

    Used only by the D prior pass: the rasteriser reads colours/scales/opacities
    from the model itself (no override argument exists), so the only way to keep
    them out of the prior graph is to hand the renderer detached values.  Values
    are copied verbatim, so the rendered depth is numerically unchanged; what
    changes is that no AccumulateGrad node can exist for them.
    """

    def __init__(self, model, names):
        self.model = model
        self.names = tuple(names)
        self.saved = {}

    @staticmethod
    def _resolve(model, name):
        parts = name.split(".")
        obj = model
        for p in parts[:-1]:
            obj = getattr(obj, p)
        return obj, parts[-1]

    def __enter__(self):
        for n in self.names:
            holder, key = self._resolve(self.model, n)
            old = holder[key]
            new = nn.Parameter(old.detach().clone(), requires_grad=False)
            holder[key] = new
            self.saved[n] = (holder, key, old)
        return self

    def __exit__(self, *exc):
        for n, (holder, key, old) in self.saved.items():
            holder[key] = old
        return False


# appearance tensors the prior pass must not be able to reach.  The residual is
# deliberately NOT frozen here: if it ever leaked into the prior graph the audit
# must be able to see it.
PRIOR_FROZEN = ("fg.params.colors", "fg.params.means", "fg.params.quats",
                "fg.params.scales", "fg.params.opacities",
                "bg.params.colors", "bg.params.means", "bg.params.quats",
                "bg.params.scales", "bg.params.opacities")


def assemble(model, res, batch, mode):
    """Assemble one logical pass and return (loss, raw_terms, extra, need).

    mode:
      A0      frozen pose path, all native terms, no residual (identity audit)
      K       composed motion, all native terms, one graph, residual reg
      D_prior base-motion-only geometry with the appearance graph frozen
      D_photo base motion detached, composed with the residual, RGB/mask only
    """
    if mode == "A0":
        geom = geom_A0(model, batch)
        terms = compute_terms(model, batch, geom, ALL_TERMS)
        return weighted_total(terms), terms, None, ALL_TERMS
    if mode == "K":
        geom = geom_K(model, res, batch)
        extra, _ = res.regularizer()
        terms = compute_terms(model, batch, geom, ALL_TERMS)
        return weighted_total(terms, extra), terms, extra, ALL_TERMS
    if mode == "D_prior":
        with freeze_params(model, PRIOR_FROZEN):
            geom = geom_D_prior(model, batch)
            terms = compute_terms(model, batch, geom, PRIOR_TERMS)
            loss = weighted_total(terms)
        return loss, terms, None, PRIOR_TERMS
    if mode == "D_photo":
        geom = geom_D_photo(model, res, batch)
        extra, _ = res.regularizer()
        terms = compute_terms(model, batch, geom, PHOTO_TERMS)
        return weighted_total(terms, extra), terms, extra, PHOTO_TERMS
    raise ValueError(mode)


# ------------------------------------------------------------------- trainer
def build_trainer(ckpt, dev, work_dir, trainable=True):
    """Load a checkpoint exactly as the frozen pipeline does (topology frozen)."""
    from flow3d.configs import (LossesConfig, OptimizerConfig, SceneLRConfig,
                                FGLRConfig, BGLRConfig, MotionLRConfig,
                                CameraPoseLRConfig, CameraScalesLRConfig)
    from flow3d.trainer import Trainer
    lr = SceneLRConfig(FGLRConfig(), BGLRConfig(), MotionLRConfig(),
                       CameraPoseLRConfig(), CameraScalesLRConfig())
    ocfg = OptimizerConfig()
    ck = torch.load(ckpt, map_location="cpu", weights_only=False)
    gs0 = int(ck.get("global_step", 0))
    ocfg.stop_control_steps = gs0
    ocfg.stop_densify_steps = gs0
    ocfg.stop_control_by_screen_steps = gs0
    os.makedirs(f"{work_dir}/checkpoints", exist_ok=True)
    trainer, _ = Trainer.init_from_checkpoint(ckpt, dev, False, lr,
                                              LossesConfig(), ocfg, work_dir=work_dir)
    mask = C.apply_trainable_mask(trainer.model, freeze_cams=True)
    if not trainable:
        for p in trainer.model.parameters():
            p.requires_grad_(False)
        mask = {n: False for n, _ in trainer.model.named_parameters()}
    trainer.trainable_mask = mask
    return trainer, gs0


def attach_residual(trainer, load_from=None):
    """Attach the residual module + its two optimizers (coef, basis)."""
    model = trainer.model
    res = ResidualMotion(model.num_fg_gaussians, model.num_frames, RESID["R"])
    dev = next(model.parameters()).device
    model.parm_resid = res.to(dev)
    res.coef.requires_grad_(True)
    res.basis.requires_grad_(True)
    opt_c = torch.optim.Adam([{"params": res.coef, "lr": RESID["lr_coef"],
                               "name": "parm_resid.coef"}])
    opt_b = torch.optim.Adam([{"params": res.basis, "lr": RESID["lr_basis"],
                               "name": "parm_resid.basis"}])
    trainer.optimizers["parm_resid.coef"] = opt_c
    trainer.optimizers["parm_resid.basis"] = opt_b
    trainer.scheduler["parm_resid.coef"] = torch.optim.lr_scheduler.LambdaLR(
        opt_c, lambda _: 1.0)
    trainer.scheduler["parm_resid.basis"] = torch.optim.lr_scheduler.LambdaLR(
        opt_b, lambda _: 1.0)
    if load_from is not None:
        ck = torch.load(load_from, map_location="cpu", weights_only=False)
        sd = ck["model"]
        res.load_state_dict({k[len("parm_resid."):]: v for k, v in sd.items()
                             if k.startswith("parm_resid.")})
        for key, opt in (("parm_resid.coef", opt_c), ("parm_resid.basis", opt_b)):
            if "optimizers" in ck and key in ck["optimizers"]:
                opt.load_state_dict(ck["optimizers"][key])
    return res


# -------------------------------------------------------------- graph audits
def graph_reachable_params(loss):
    """Diagnostic: number of distinct autograd nodes reachable from `loss`."""
    seen, stack = 0, [loss.grad_fn]
    visited = set()
    while stack:
        fn = stack.pop()
        if fn is None or id(fn) in visited:
            continue
        visited.add(id(fn))
        seen += 1
        for nxt, _ in getattr(fn, "next_functions", ()):
            if nxt is not None:
                stack.append(nxt)
    return {"n_graph_nodes": seen}


def structural_reach(model, loss):
    """Which trainable parameters are STRUCTURALLY in the graph of `loss`?

    Uses torch.autograd.grad(..., allow_unused=True): autograd returns None only
    when there is no path from `loss` to the parameter, and a (possibly all-zero)
    tensor when there is one.  So this distinguishes "not in the graph" from
    "in the graph but its gradient happens to be zero" -- which requires_grad
    flags and post-hoc .grad inspection cannot do reliably.
    """
    ps = [(n, p) for n, p in model.named_parameters() if p.requires_grad]
    grads = torch.autograd.grad(loss, [p for _, p in ps], allow_unused=True,
                                retain_graph=True)
    present = sorted(n for (n, _), g in zip(ps, grads) if g is not None)
    absent = sorted(n for (n, _), g in zip(ps, grads) if g is None)
    norms = {}
    for (n, _), g in zip(ps, grads):
        if g is None:
            continue
        c = param_class(n)
        norms[c] = norms.get(c, 0.0) + float((g.detach() ** 2).sum())
    for k in norms:
        norms[k] = norms[k] ** 0.5
    return {"present": present, "absent": absent,
            "present_by_class": sorted({param_class(n) for n in present}),
            "norm_by_class": norms}


def reach_report(model, loss):
    """Legacy alias: names of trainable parameters structurally in the graph."""
    return structural_reach(model, loss)["present"]


def grad_norms(model):
    out = {}
    for n, p in model.named_parameters():
        if p.grad is None:
            continue
        c = param_class(n)
        out[c] = out.get(c, 0.0) + float((p.grad.detach() ** 2).sum())
    for k in out:
        out[k] = out[k] ** 0.5
    return out


def zero_grads(model):
    for p in model.parameters():
        p.grad = None


def snapshot_ckpt_source_sha(d):
    out = {}
    for root, _, files in os.walk(d):
        for f in sorted(files):
            if f.endswith((".ckpt", ".json", ".jsonl", ".csv", ".md")):
                p = os.path.join(root, f)
                out[os.path.relpath(p, W)] = sha256_file(p)
    return out
