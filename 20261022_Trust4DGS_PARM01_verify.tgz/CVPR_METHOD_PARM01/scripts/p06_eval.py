"""CVPR-METHOD-PARM01 evaluator: one code path for every arm, frozen identities.

The frozen evaluators (ps02_eval.py novel-view, pc_eval_train.py train-source)
cannot render a PARM01 K/D checkpoint, because those arms carry a residual motion
that the frozen SceneModel does not know about.  They are therefore kept byte
unmodified and used verbatim for the residual-free arms (A_NATIVE, E_EARLY_ONLY,
A0), while this script reproduces their metric code exactly and adds ONE thing:
when the checkpoint contains `parm_resid.*`, the foreground poses are composed
with the residual before rendering.

Identity is not argued, it is measured (see p05_eval.sh):
  * this script run on the residual-free A0 / A_NATIVE / E_EARLY_ONLY checkpoints
    must reproduce the archived frozen evaluator numbers exactly.

Metric identities used (all imported from the frozen helpers, never re-implemented):
  val split + covisible/2x/val mask + SAM2 FG mask   -> m1_eval / ps02_eval rules
  PSNR / LPIPS                                        -> m1_eval._psnr / _lp
  PROXY_FG, PROXY_BG, BOUNDARY k=9, OCCLUSION_HALO    -> ps02_eval.band_masks
  train-source FG (masks/2x object mask)              -> pc_eval_train.fg_mask_train
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

W = "/home/star/IEEE/Trust4DGS"
sys.path.insert(0, f"{W}/METHOD01_CAPE4D/scripts")
sys.path.insert(0, f"{W}/PAPER_METHOD_STAGE02/scripts")
sys.path.insert(0, f"{W}/PAPER_CORE_BASELINE_REALISM/scripts")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cape_common as C          # noqa: E402
import m1_eval as M              # noqa: E402
import ps02_eval as PS           # noqa: E402  (band_masks / agg reused)
import pc_eval_train as PT       # noqa: E402  (train-source fg mask rule)

import parm_common as K          # noqa: E402


def load_model(ckpt, dev, work_dir):
    """Frozen loader + optional residual, taken from the checkpoint itself."""
    from flow3d.configs import (LossesConfig, OptimizerConfig, SceneLRConfig,
                                FGLRConfig, BGLRConfig, MotionLRConfig,
                                CameraPoseLRConfig, CameraScalesLRConfig)
    from flow3d.trainer import Trainer
    lr = SceneLRConfig(FGLRConfig(), BGLRConfig(), MotionLRConfig(),
                       CameraPoseLRConfig(), CameraScalesLRConfig())
    os.makedirs(f"{work_dir}/checkpoints", exist_ok=True)
    tr, _ = Trainer.init_from_checkpoint(ckpt, dev, False, lr, LossesConfig(),
                                         OptimizerConfig(), work_dir=work_dir)
    model = tr.model
    ck = torch.load(ckpt, map_location="cpu", weights_only=False)
    # init_from_checkpoint returns ckpt["epoch"] (0 in every saved state), not the
    # training step; the global step is the checkpoint's own field.
    gs = int(ck.get("global_step", 0))
    has_resid = any(k.startswith("parm_resid.") for k in ck["model"])
    res = None
    if has_resid:
        res = K.ResidualMotion(model.num_fg_gaussians, model.num_frames,
                               K.RESID["R"]).to(dev)
        res.load_state_dict({k[len("parm_resid."):]: v for k, v in ck["model"].items()
                             if k.startswith("parm_resid.")})
        res.eval()
        model.parm_resid = res
    return tr, model, res, gs, has_resid


def render_frame(model, res, tid, w2c, Kk, wh):
    """Same call as the frozen evaluator; composed poses when a residual exists."""
    if res is None:
        return model.render(tid, w2c, Kk, wh)
    t = torch.tensor([tid], device=w2c.device)
    T = K.compose(K.base_transforms(model, t), res.transforms(t))
    means, quats = K.pose_from_transforms(model, T)
    return model.render(tid, w2c, Kk, wh, means=means[:, 0], quats=quats[:, 0])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scene", default="Truck")
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--arm", required=True)
    ap.add_argument("--mode", default="novel", choices=["novel", "train"])
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--work-root", default=None)
    a = ap.parse_args()
    dev = torch.device("cuda:0")
    os.makedirs(a.outdir, exist_ok=True)
    work_root = a.work_root or f"{K.S}/cache/eval_reload"
    os.makedirs(f"{work_root}/{a.arm}_{a.mode}", exist_ok=True)

    from flow3d.data.nvidia_dataset import NvidiaDataset
    from PIL import Image

    ddir = C.data_dir(a.scene)
    norm = f"{ddir}/flow3d_preprocessed/cache/scene_norm_dict.pth"
    try:
        snd = torch.load(norm, map_location="cpu", weights_only=False)
    except Exception:
        snd = torch.load(norm, map_location="cpu")

    t0 = time.time()
    tr, model, res, gs, has_resid = load_model(
        a.ckpt, dev, f"{work_root}/{a.arm}_{a.mode}/reload")
    load_s = time.time() - t0
    lp = M._lpips_fn(dev)

    if a.mode == "novel":
        val = NvidiaDataset(data_dir=ddir, split="val", factor=2,
                            scene_norm_dict=snd, load_from_cache=True)
        rows, n_skip, n_eval, render_t = [], 0, 0, []
        H, Wd = val.imgs.shape[1], val.imgs.shape[2]
        with torch.no_grad():
            for i in range(len(val)):
                fn = val.frame_names[i]
                w2c = val.w2cs[i:i + 1].to(dev)
                Kk = val.Ks[i:i + 1].to(dev)
                tid = int(val.time_ids[i].item())
                torch.cuda.synchronize()
                tr0 = time.time()
                out = render_frame(model, res, tid, w2c, Kk, (Wd, H))
                torch.cuda.synchronize()
                render_t.append(time.time() - tr0)
                pred = out["img"][0].detach().float().clamp(0, 1)
                gt = val.imgs[i].to(dev).float()[..., :3]
                mp = os.path.join(ddir, "covisible/2x/val", fn + ".png")
                if not os.path.exists(mp):
                    n_skip += 1
                    continue
                m = np.array(Image.open(mp).convert("L"))
                if (m.shape[0], m.shape[1]) != (H, Wd):
                    m = np.array(Image.open(mp).convert("L").resize(
                        (Wd, H), Image.NEAREST))
                vis = (torch.from_numpy(m).to(dev).float() / 255.0 > 0.5).float()
                if float(vis.sum()) < 1:
                    n_skip += 1
                    continue
                n_eval += 1
                fg = M._fg_mask(a.scene, fn, dev)
                if fg is None:
                    fg = torch.zeros_like(vis)
                fgm = vis * fg
                bgm = vis * (1.0 - fg)
                band, halo_all = PS.band_masks(fg)
                bandm = vis * band
                halo = vis * (1.0 - fg) * halo_all
                r = {"frame": fn, "val_index": i, "time_id": tid,
                     "n_vis": float(vis.sum()), "n_fg": float(fgm.sum()),
                     "n_bg": float(bgm.sum()), "n_band": float(bandm.sum()),
                     "n_halo": float(halo.sum()),
                     "full_psnr": M._psnr(pred, gt, vis),
                     "full_lpips": M._lp(lp, pred, gt, vis)}
                for key, msk in (("fg", fgm), ("bg", bgm), ("band", bandm),
                                 ("halo", halo)):
                    if float(msk.sum()) >= 1:
                        r[f"{key}_psnr"] = M._psnr(pred, gt, msk)
                        r[f"{key}_lpips"] = M._lp(lp, pred, gt, msk)
                    else:
                        r[f"{key}_psnr"] = float("nan")
                        r[f"{key}_lpips"] = float("nan")
                rows.append(r)
        summ = {
            "scene": a.scene, "arm": a.arm, "n_eval": n_eval, "n_skip": n_skip,
            "n_rows": len(rows),
            "n_fg_rows": sum(1 for r in rows if not np.isnan(r["fg_psnr"])),
            "n_bg_rows": sum(1 for r in rows if not np.isnan(r["bg_psnr"])),
            "n_band_rows": sum(1 for r in rows if not np.isnan(r["band_psnr"])),
            "n_halo_rows": sum(1 for r in rows if not np.isnan(r["halo_psnr"])),
            "num_fg_gaussians": int(model.num_fg_gaussians),
            "num_bg_gaussians": int(model.num_bg_gaussians),
            "num_parameters": int(sum(p.numel() for p in model.parameters())),
            "has_residual": bool(has_resid),
            "n_residual_params": int(res.n_params()) if res is not None else 0,
            "render_s_mean": float(np.mean(render_t)),
            "render_s_median": float(np.median(render_t)),
            "render_s_total": float(np.sum(render_t)),
            "model_load_s": load_s,
            "global_step": int(gs),
        }
        for met in ("full", "fg", "bg", "band", "halo"):
            summ[f"novel_{met}_psnr"] = PS.agg(rows, f"{met}_psnr")
            summ[f"novel_{met}_lpips"] = PS.agg(rows, f"{met}_lpips")
        ordered = sorted(rows, key=lambda r: r["val_index"])
        cut = (3 * len(ordered)) // 4
        for tag, sl in (("late_quarter", ordered[cut:]),
                        ("early_quarter", ordered[:cut])):
            summ[f"{tag}_fg_psnr"] = PS.agg(sl, "fg_psnr")
            summ[f"{tag}_bg_psnr"] = PS.agg(sl, "bg_psnr")
            summ[f"{tag}_band_psnr"] = PS.agg(sl, "band_psnr")
        b = np.linspace(0, len(ordered), 7).astype(int)
        for key in ("fg", "full", "bg", "band"):
            summ[f"temporal_bins_{key}_psnr"] = [
                PS.agg(ordered[int(b[k]):int(b[k + 1])], f"{key}_psnr")
                for k in range(6)]
        json.dump({"summary": summ, "per_frame": rows},
                  open(f"{a.outdir}/{a.arm}.json", "w"), indent=1)
        print("PARM01_EVAL_DONE " + json.dumps(summ), flush=True)
    else:
        trn = NvidiaDataset(data_dir=ddir, split="train", factor=2,
                            scene_norm_dict=snd, load_from_cache=True)
        H, Wd = trn.imgs.shape[1], trn.imgs.shape[2]
        rows = []
        with torch.no_grad():
            for i in range(len(trn.frame_names)):
                fn = trn.frame_names[i]
                m = PT.fg_mask_train(a.scene, fn, dev)
                if m is None or float(m.sum()) < 1:
                    continue
                tid = int(trn.time_ids[i].item())
                out = render_frame(model, res, tid, trn.w2cs[i:i + 1].to(dev),
                                   trn.Ks[i:i + 1].to(dev), (Wd, H))
                pred = out["img"][0].detach().float().clamp(0, 1)
                gt = trn.imgs[i].to(dev).float()[..., :3]
                rows.append({"frame": fn, "train_index": i, "time_id": tid,
                             "n_fg": float(m.sum()),
                             "fg_psnr": M._psnr(pred, gt, m),
                             "fg_lpips": M._lp(lp, pred, gt, m)})
        summ = {"scene": a.scene, "arm": a.arm,
                "n_train_frames_scored": len(rows),
                "train_source_fg_psnr": float(np.mean([r["fg_psnr"] for r in rows])),
                "train_source_fg_lpips": float(np.mean([r["fg_lpips"] for r in rows])),
                "has_residual": bool(has_resid), "global_step": int(gs),
                "metric": "train-source render vs train GT inside the DYCHECK object "
                          "mask (masks/2x), same PSNR/LPIPS helpers as the frozen "
                          "novel-view evaluator; DEV-only"}
        json.dump({"summary": summ, "per_frame": rows},
                  open(f"{a.outdir}/train_{a.arm}.json", "w"), indent=1)
        print("PARM01_TRAIN_EVAL_DONE " + json.dumps(summ), flush=True)
    del tr, model
    torch.cuda.empty_cache()
    return 0


if __name__ == "__main__":
    sys.exit(main())
