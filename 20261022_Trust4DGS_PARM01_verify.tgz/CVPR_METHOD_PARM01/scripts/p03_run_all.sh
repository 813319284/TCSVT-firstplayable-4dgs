#!/bin/bash
# CVPR-METHOD-PARM01 stage 3: one common prefix, then the three arms, sequential.
#
#   PREFIX : frozen native trainer (ps_stage.py --arm A) 0 -> 4000
#   A0     : frozen native trainer (ps_stage.py --arm A) 4000 -> 13000
#   K      : p04_train.py --arm K  4000 -> 13000  (one graph, composed motion)
#   D      : p04_train.py --arm D  4000 -> 13000  (separated prior / photometric)
#
# A0 uses the frozen script itself, so the control arm is the frozen code path
# with the frozen weights; K and D differ only in graph construction.  Refuses to
# start unless the GPU gate says GO.
set -u
cd "$(dirname "$0")"
source /home/star/IEEE/Trust4DGS/audit_SERVER_REGEN_SMOKE/g09f_cuda_env.sh >/dev/null 2>&1
export CUDA_VISIBLE_DEVICES=0
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=/home/star/miniconda3/envs/trust4dgs/bin/python
W=/home/star/IEEE/Trust4DGS
S=$W/CVPR_METHOD_PARM01
STAGE=$W/PAPER_CVPR_CORE01/scripts/frozen_source/ps_stage.py
mkdir -p "$S/logs" "$S/runs/Truck"

echo "PARM01_STAGE3_START $(date -Is)"
$PY - "$S" <<'EOF'
import json, sys
S = sys.argv[1]
g = json.load(open(f"{S}/PARM01_GATE_AND_METRICS.json"))
if g.get("verdict") != "GO":
    print("REFUSED: gate verdict", g.get("verdict")); sys.exit(2)
print("gate GO, projected GPU-hours", g["cost_projection"]["total_gpu_hours"])
EOF
[ $? -ne 0 ] && { echo "STAGE_ABORT gate"; exit 2; }

PREFIX=$S/runs/Truck/PREFIX/checkpoints/last.ckpt

if [ -f "$PREFIX" ]; then
  echo "PREFIX exists, reusing (no retrain)"
else
  echo "=== PREFIX 0->4000 $(date -Is) ==="
  $PY "$STAGE" --scene Truck --arm A --steps 4000 --seed 42 \
      --init-ckpt "$W/R2_A01/base/Truck/checkpoints/init.ckpt" \
      --out "$S/runs/Truck/PREFIX" > "$S/logs/prefix.log" 2>&1
  rc=$?; echo "prefix rc=$rc"
  [ $rc -ne 0 ] && { echo "STAGE_ABORT prefix"; exit 3; }
  [ -f "$PREFIX" ] || { echo "STAGE_ABORT prefix_missing"; exit 3; }
fi

echo "=== A0 4000->13000 (frozen native trainer) $(date -Is) ==="
$PY "$STAGE" --scene Truck --arm A --steps 9000 --seed 42 --measure \
    --init-ckpt "$PREFIX" --out "$S/runs/Truck/A0" > "$S/logs/a0.log" 2>&1
rc=$?; echo "A0 rc=$rc"
[ $rc -ne 0 ] && { echo "STAGE_ABORT A0"; exit 4; }

echo "=== K 4000->13000 $(date -Is) ==="
$PY p04_train.py --arm K > "$S/logs/k.log" 2>&1
rc=$?; echo "K rc=$rc"
[ $rc -ne 0 ] && { echo "STAGE_ABORT K"; exit 5; }

echo "=== D 4000->13000 $(date -Is) ==="
$PY p04_train.py --arm D > "$S/logs/d.log" 2>&1
rc=$?; echo "D rc=$rc"
[ $rc -ne 0 ] && { echo "STAGE_ABORT D"; exit 6; }

echo "PARM01_STAGE3_DONE $(date -Is)"
