"""CVPR-METHOD-PARM01 step 3: continuation training of one arm from the fork.

Arms
  A0  is NOT run here: it is the frozen native trainer itself
      (ps_stage.py --scene Truck --arm A --steps 9000), so the control arm has
      byte-for-byte the frozen training code.
  K   one graph, T = T_base @ Delta, full native objective + residual reg.
  D   two graphs per update (prior pass / photometric pass) with the routing
      that p01+p02 verified structurally.

Everything else is identical across arms: same prefix checkpoint, same frozen
DataLoader order (sequential, no shuffle, batch 8 -> exactly the batches A0
sees), same LossesConfig, same optimizers/schedulers for the native parameters,
same number of updates, same seed, topology frozen (density control already
stopped at the fork).
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parm_common as K

S = K.S
TIME_LIMIT_S = 3.4 * 3600.0     # hard guard inside the 4 GPU-hour step budget


def rot_angle(R):
    """(...,3,3) -> (...) rotation angle, from the trace."""
    tr = R.diagonal(dim1=-2, dim2=-1).sum(-1)
    return torch.acos(((tr - 1.0) / 2.0).clamp(-1.0, 1.0))


def free_gib():
    f, _ = torch.cuda.mem_get_info()
    return f / 2 ** 30


def presence(model):
    """Cheap structural witness after a backward: a parameter absent from the
    graph has grad None (p01/p02 prove this witness equals the autograd-DAG test)."""
    return sorted(n for n, p in model.named_parameters() if p.grad is not None)


def finalize(arm, out):
    """Rebuild run.json from artifacts when only the post-run audit crashed.

    Nothing is retrained and nothing is overwritten except run.json; the
    checkpoint and the per-update log are used exactly as produced.
    """
    ckpt = f"{out}/checkpoints/last.ckpt"
    rows = [json.loads(x) for x in open(f"{out}/train_log.jsonl")]
    ck = torch.load(ckpt, map_location="cpu", weights_only=False)
    sd = ck["model"]
    n_fg = len(sd["fg.params.means"])
    n_bg = len(sd["bg.params.means"])
    coef = sd["parm_resid.coef"]
    basis = sd["parm_resid.basis"]
    prefix = f"{K.PREFIX_DIR}/checkpoints/last.ckpt"
    rep = {
        "step": "CVPR_METHOD_PARM01", "scene": K.SCENE, "arm": arm,
        "finalized_post_hoc": True,
        "finalize_note": "the arm trained to completion and saved its checkpoint; "
                         "only the post-run trajectory audit raised "
                         "(torch.linalg.matrix_angle does not exist), so run.json "
                         "is rebuilt from train_log.jsonl + the checkpoint. The "
                         "authoritative trajectory audit is recomputed for all "
                         "arms on CPU in p07_deliver.py / "
                         "PARM01_TRAJECTORY_AUDIT.json.",
        "init_ckpt": prefix, "init_ckpt_sha256": K.sha256_file(prefix),
        "init_global_step": K.FORK_STEP, "updates_requested": K.N_STEPS,
        "updates_done": len(rows), "gs1": int(ck["global_step"]),
        "stop_reason": None,
        "s_per_update_mean": float(np.mean([r["step_s"] for r in rows])),
        "mean_s_per_step_last200": float(np.mean([r["step_s"] for r in rows[-200:]])),
        "wall_train_s": float(np.sum([r["step_s"] for r in rows])),
        "peak_vram_gib": float(max(r["vram_gib"] for r in rows)),
        "counts_final": {"num_fg": int(n_fg), "num_bg": int(n_bg)},
        "topology_frozen": True,
        "residual": dict(K.RESID, n_params=int(coef.numel() + basis.numel())),
        "residual_final": {"coef_abs_mean": float(coef.abs().mean()),
                           "coef_abs_max": float(coef.abs().max()),
                           "coef_frac_nonzero": float((coef.abs() > 1e-8).float().mean()),
                           "basis_abs_mean": float(basis.abs().mean())},
        "native_weights": dict(K.NATIVE_W),
        "loss_first": rows[0]["loss"], "loss_last": rows[-1]["loss"],
        "present_prior_last": rows[-1].get("present_prior", rows[-1].get("present")),
        "present_photo_last": rows[-1].get("present_photo", rows[-1].get("present")),
        "ckpt_path": ckpt, "ckpt_sha256": K.sha256_file(ckpt),
        "gate_verdict": K.jload(f"{S}/PARM01_GATE_AND_METRICS.json").get("verdict"),
        "gate_sha256": K.sha256_file(f"{S}/PARM01_GATE_AND_METRICS.json"),
    }
    K.jdump(rep, f"{out}/run.json")
    print("FINALIZE_DONE " + json.dumps({k: rep[k] for k in
                                         ("arm", "updates_done", "gs1", "wall_train_s",
                                          "ckpt_sha256")}), flush=True)
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", required=True, choices=["K", "D"])
    ap.add_argument("--updates", type=int, default=K.N_STEPS)
    ap.add_argument("--min_free_gib", type=float, default=4.0)
    ap.add_argument("--finalize-only", action="store_true",
                    help="do not train: rebuild run.json from the finished "
                         "train_log.jsonl + checkpoint (used when only the "
                         "post-run audit crashed)")
    a = ap.parse_args()

    dev = torch.device("cuda:0")
    K.set_seed()
    out = K.ARM_DIRS[a.arm]
    if getattr(a, "finalize_only", False):
        return finalize(a.arm, out)
    os.makedirs(f"{out}/checkpoints", exist_ok=True)
    if free_gib() < a.min_free_gib:
        print(f"ABORT low_free_vram {free_gib():.2f} GiB", flush=True)
        return 3

    prefix = f"{K.PREFIX_DIR}/checkpoints/last.ckpt"
    if not os.path.exists(prefix):
        print(f"ABORT missing prefix {prefix}", flush=True)
        return 3
    gid = K.jload(f"{S}/PARM01_GATE_AND_METRICS.json")
    if gid.get("verdict") != "GO":
        print("ABORT gate not GO", flush=True)
        return 3

    t_load = time.time()
    trainer, gs0 = K.build_trainer(prefix, dev, f"{out}/_reload", trainable=True)
    model = trainer.model
    res = K.attach_residual(trainer)
    load_s = time.time() - t_load
    if gs0 != K.FORK_STEP:
        print(f"ABORT prefix global_step {gs0} != {K.FORK_STEP}", flush=True)
        return 3
    counts0 = {"num_fg": int(model.num_fg_gaussians),
               "num_bg": int(model.num_bg_gaussians)}

    ds = K.load_train_ds()
    loader = K.make_loader(ds)
    from flow3d.data.utils import to_device

    log = open(f"{out}/train_log.jsonl", "w")
    t0 = time.time()
    torch.cuda.reset_peak_memory_stats()
    rows, stop_reason = [], None
    step_t = 0.0
    print(f"START {a.arm} gs0={gs0} updates={a.updates} "
          f"fg={counts0['num_fg']} bg={counts0['num_bg']} load={load_s:.1f}s",
          flush=True)

    n_done = 0
    while n_done < a.updates:
        for batch in loader:
            if n_done >= a.updates:
                break
            if time.time() - t0 > TIME_LIMIT_S:
                stop_reason = "TIME_LIMIT"
                print(f"ABORT time limit at u={n_done}", flush=True)
                break
            tu = time.time()
            b = to_device(batch, dev)
            rec = {"u": n_done, "gs": int(trainer.global_step)}
            if a.arm == "K":
                loss, terms, extra, _ = K.assemble(model, res, b, "K")
                loss.backward()
                rec["loss"] = float(loss.detach())
                rec["extra_reg"] = float(extra.detach()) if extra is not None else 0.0
                rec["terms"] = {k: float(v.detach()) for k, v in terms.items()}
                rec["present"] = presence(model)
            else:
                l1, t1, _, _ = K.assemble(model, res, b, "D_prior")
                l1.backward()
                rec["loss_prior"] = float(l1.detach())
                rec["terms_prior"] = {k: float(v.detach()) for k, v in t1.items()}
                rec["present_prior"] = presence(model)
                l2, t2, extra, _ = K.assemble(model, res, b, "D_photo")
                l2.backward()
                rec["loss_photo"] = float(l2.detach())
                rec["extra_reg"] = float(extra.detach()) if extra is not None else 0.0
                rec["terms_photo"] = {k: float(v.detach()) for k, v in t2.items()}
                rec["present_photo"] = presence(model)
                rec["loss"] = rec["loss_prior"] + rec["loss_photo"]
            gn = K.grad_norms(model)
            for opt in trainer.optimizers.values():
                opt.step()
                opt.zero_grad(set_to_none=True)
            for sch in trainer.scheduler.values():
                sch.step()
            trainer.global_step += 1
            model._current_xys = None
            model._current_radii = None
            rec["grad_norm_by_class"] = gn
            rec["step_s"] = time.time() - tu
            rec["vram_gib"] = torch.cuda.max_memory_allocated() / 2 ** 30
            log.write(json.dumps(rec) + "\n")
            rows.append(rec)
            n_done += 1
            step_t += rec["step_s"]
            if n_done % 200 == 0:
                rec_ckpt = {
                    "step": n_done, "gs": int(trainer.global_step),
                    "loss": float(np.mean([r["loss"] for r in rows[-200:]])),
                    "s_per_step": float(np.mean([r["step_s"] for r in rows[-200:]])),
                    "elapsed_s": time.time() - t0,
                    "coef_abs_mean": float(res.coef.detach().abs().mean()),
                    "coef_abs_max": float(res.coef.detach().abs().max()),
                    "basis_abs_mean": float(res.basis.detach().abs().mean()),
                }
                log.flush()
                print(f"{a.arm} u={n_done}/{a.updates} "
                      f"L={rec_ckpt['loss']:.5f} "
                      f"s/step={rec_ckpt['s_per_step']:.3f} "
                      f"|a|mean={rec_ckpt['coef_abs_mean']:.3e} "
                      f"t={rec_ckpt['elapsed_s']:.0f}s", flush=True)
        if stop_reason:
            break
    log.close()

    ckpt = f"{out}/checkpoints/last.ckpt"
    trainer.save_checkpoint(ckpt)
    wall = time.time() - t0

    # trajectory audit: how much do the base motion and the residual actually move?
    traj = {}
    with torch.no_grad():
        tsel = torch.tensor([0, 51, 102, 153, 203], device=dev)
        Tb = K.base_transforms(model, tsel)
        Tr = res.transforms(tsel)
        Tc = K.compose(Tb, Tr)
        means = model.fg.params["means"]
        p = torch.einsum("pnij,pj->pni", Tb, torch.nn.functional.pad(
            means, (0, 1), value=1.0))
        pc = torch.einsum("pnij,pj->pni", Tc, torch.nn.functional.pad(
            means, (0, 1), value=1.0))
        traj["residual_displacement_rms"] = [
            float((pc - p)[:, i].norm(dim=-1).pow(2).mean().sqrt())
            for i in range(len(tsel))]
        traj["residual_rot_angle_rad_mean"] = [
            float(rot_angle(Tr[:, i, :3, :3]).mean())
            for i in range(len(tsel))]
        traj["frames"] = [int(x) for x in tsel]
        traj["residual_coef_abs_mean"] = float(res.coef.detach().abs().mean())
        traj["residual_coef_abs_max"] = float(res.coef.detach().abs().max())
        traj["residual_coef_frac_nonzero"] = float(
            (res.coef.detach().abs() > 1e-8).float().mean())

    rep = {
        "step": "CVPR_METHOD_PARM01", "scene": K.SCENE, "arm": a.arm,
        "init_ckpt": prefix, "init_ckpt_sha256": K.sha256_file(prefix),
        "init_global_step": gs0, "updates_requested": a.updates,
        "updates_done": n_done, "gs1": int(trainer.global_step),
        "stop_reason": stop_reason, "load_s": load_s, "wall_s": wall,
        "s_per_update_mean": float(step_t / max(n_done, 1)),
        "mean_s_per_step_last200": float(np.mean([r["step_s"] for r in rows[-200:]])),
        "peak_vram_gib": float(torch.cuda.max_memory_allocated() / 2 ** 30),
        "counts_final": {"num_fg": int(model.num_fg_gaussians),
                         "num_bg": int(model.num_bg_gaussians)},
        "topology_frozen": counts0 == {"num_fg": int(model.num_fg_gaussians),
                                       "num_bg": int(model.num_bg_gaussians)},
        "residual": dict(K.RESID, n_params=int(res.n_params())),
        "native_weights": dict(K.NATIVE_W),
        "loss_first": rows[0]["loss"], "loss_last": rows[-1]["loss"],
        "trajectory": traj,
        "ckpt_path": ckpt, "ckpt_sha256": K.sha256_file(ckpt),
        "gate_verdict": gid.get("verdict"),
        "gate_sha256": K.sha256_file(f"{S}/PARM01_GATE_AND_METRICS.json"),
        "n_optimizers": len(trainer.optimizers),
        "n_schedulers": len(trainer.scheduler),
    }
    K.jdump(rep, f"{out}/run.json")
    print("RUN_DONE " + json.dumps({k: rep[k] for k in
                                    ("scene", "arm", "updates_done", "wall_s",
                                     "s_per_update_mean", "peak_vram_gib",
                                     "ckpt_sha256", "stop_reason")}), flush=True)
    return 0 if n_done == a.updates else 5


if __name__ == "__main__":
    sys.exit(main())
