"""CVPR-METHOD-PARM01 step 2: GPU identity + separation gate (before any training).

Refuses to let any arm train unless ALL of the following hold on the real
renderer and the real data:

  G1  the composed pose with zero residual is bit-identical to the frozen pose;
  G2  the frozen model's own render and the composed-pose render are bit-identical
      (this is the "initial render must be identical" requirement, measured, not
      argued);
  G3  the re-implemented A0 loss reproduces frozen Trainer.compute_losses term by
      term (bitwise) and its parameter gradients bitwise;
  G4  the same is true for the K arm at delta = 0, i.e. adding the residual module
      changes nothing before it has learned anything;
  G5  the real autograd graphs satisfy the design:
        D prior pass  -> base motion only
        D photo pass  -> residual + appearance only
        K             -> everything
        A0            -> everything except the residual
  G6  supervision targets (depth / tracks / masks) are byte-identical before and
      after every pass;
  G7  a 3-step smoke run of each trainable arm works (finite loss, parameters
      move, global_step advances, exactly one optimizer/scheduler step per update)
      and the measured seconds-per-update imply a total cost inside the 4 GPU-hour
      budget.

Writes PARM01_GATE_AND_METRICS.json and PARM01_GRADIENT_SEPARATION_AUDIT.json
(gpu section).  Exits non-zero on STOP.
"""
import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parm_common as K

S = K.S
FAIL = []
REC = {}


def check(name, ok, detail=None):
    rec = {"check": name, "ok": bool(ok)}
    if detail is not None:
        rec["detail"] = detail
    if not ok:
        FAIL.append(rec)
    print(("PASS " if ok else "FAIL ") + name
          + ("" if detail is None else "  " + json.dumps(detail, default=float)),
          flush=True)
    return rec


def clone_batch(b):
    out = {}
    for k, v in b.items():
        if torch.is_tensor(v):
            out[k] = v.clone()
        elif isinstance(v, list):
            out[k] = [x.clone() if torch.is_tensor(x) else x for x in v]
        else:
            out[k] = v
    return out


def same_batch(a, b):
    for k in a:
        va, vb = a[k], b[k]
        if torch.is_tensor(va):
            if not torch.equal(va, vb):
                return k
        elif isinstance(va, list):
            for x, y in zip(va, vb):
                if torch.is_tensor(x):
                    if not torch.equal(x, y):
                        return k
                elif x != y:
                    return k
        elif va != vb:
            return k
    return None


def grad_snapshot(model):
    return {n: (p.grad.detach().clone() if p.grad is not None else None)
            for n, p in model.named_parameters()}


def _rel(ga, gb):
    if ga is None or gb is None:
        return None
    return float((ga - gb).abs().max()) / max(float(ga.abs().max()), 1e-12)


def grad_cmp(g_ref, g_self, g_mine):
    """Compare my gradients against frozen ones, relative to the frozen self-noise.

    gsplat's backward is not deterministic (atomic accumulation), so "bitwise
    gradient parity" is not a property any implementation can have.  What can be
    required is that my-vs-frozen disagreement is inside the same rasteriser noise
    that the frozen code shows against itself on the identical batch.
    """
    per, bad = {}, []
    worst_ratio, worst_name = 0.0, None
    for n in g_ref:
        d_self = _rel(g_ref.get(n), g_self.get(n))
        d_mine = _rel(g_ref.get(n), g_mine.get(n))
        if d_self is None or d_mine is None:
            per[n] = {"self": d_self, "mine": d_mine}
            if (g_ref.get(n) is None) != (g_mine.get(n) is None):
                bad.append(n)
            continue
        tol = max(10.0 * d_self, 1e-6)
        ratio = d_mine / max(d_self, 1e-12)
        per[n] = {"self": d_self, "mine": d_mine, "ratio": ratio,
                  "ok": bool(d_mine <= tol)}
        if not per[n]["ok"]:
            bad.append(n)
        if d_self > 0 and ratio > worst_ratio:
            worst_ratio, worst_name = ratio, n
    return {"per_param": per, "bad": bad, "worst_ratio": worst_ratio,
            "worst_param": worst_name,
            "max_self_noise": max([v["self"] for v in per.values()
                                   if isinstance(v, dict) and v.get("self") is not None]
                                  or [0.0]),
            "max_mine_diff": max([v["mine"] for v in per.values()
                                  if isinstance(v, dict) and v.get("mine") is not None]
                                 or [0.0])}


def main():
    os.makedirs(f"{S}/logs", exist_ok=True)
    dev = torch.device("cuda:0")
    free, total = torch.cuda.mem_get_info()
    free_gib = free / 2 ** 30
    gate = {"step": "CVPR_METHOD_PARM01", "stage": "p02_gpu_gate",
            "gpu": torch.cuda.get_device_name(0),
            "free_vram_gib_at_start": free_gib,
            "budget_gpu_hours": 4.0}
    if free_gib < 4.0:
        gate["verdict"] = "STOP"
        gate["reason"] = f"free VRAM {free_gib:.2f} GiB < 4.0"
        K.jdump(gate, f"{S}/PARM01_GATE_AND_METRICS.json")
        print("GATE STOP low_vram", flush=True)
        return 3

    K.set_seed()
    torch.cuda.reset_peak_memory_stats()
    t_loaded = time.time()
    trainer, gs0 = K.build_trainer(K.FROZEN_A_CKPT, dev, f"{S}/cache/_p02_reload",
                                   trainable=True)
    model = trainer.model
    res = K.attach_residual(trainer)
    gate["load_ckpt"] = K.FROZEN_A_CKPT
    gate["load_ckpt_sha256"] = K.sha256_file(K.FROZEN_A_CKPT)
    gate["loaded_global_step"] = gs0
    gate["load_s"] = time.time() - t_loaded
    gate["num_fg"] = int(model.num_fg_gaussians)
    gate["num_bg"] = int(model.num_bg_gaussians)
    gate["num_motion_bases"] = int(model.num_motion_bases)
    gate["num_frames"] = int(model.num_frames)

    ds = K.load_train_ds()
    loader = K.make_loader(ds)
    from flow3d.data.utils import to_device
    batches = []
    for i, b in enumerate(loader):
        batches.append(to_device(b, dev))
        if i >= 1:
            break
    gate["n_gate_batches"] = len(batches)
    gate["batch_shapes"] = {k: (list(v.shape) if torch.is_tensor(v) else
                                [list(x.shape) for x in v])
                            for k, v in batches[0].items() if k != "frame_names"}

    # ---------------------------------------------------------------- G1 / G2
    with torch.no_grad():
        b = batches[0]
        ts = b["ts"]
        Tb = K.base_transforms(model, ts)
        m_ref, q_ref = model.compute_poses_all(ts)
        Tc = K.compose(Tb, res.transforms(ts))
        m_c, q_c = K.pose_from_transforms(model, Tc)
        g1_m = float((m_c - m_ref).abs().max())
        g1_q = float((q_c - q_ref).abs().max())
        # render identity.  The composed geometry is built at the SAME batch size
        # the renderer itself uses internally (B=1), otherwise the two einsums
        # (B=1 vs B=8) differ in the last bits and the test would measure float
        # reduction order instead of the residual.
        W_, H_ = int(ds.imgs.shape[2]), int(ds.imgs.shape[1])
        rend, batch_round = [], []
        for i in range(2):
            w2c = b["w2cs"][None, i]
            Kk = b["Ks"][None, i]
            t_i = int(ts[i].item())
            t1 = torch.tensor([t_i], device=dev)
            T1 = K.compose(K.base_transforms(model, t1), res.transforms(t1))
            m1, q1 = K.pose_from_transforms(model, T1)
            o1 = model.render(t_i, w2c, Kk, (W_, H_))
            o2 = model.render(t_i, w2c, Kk, (W_, H_),
                              means=m1[:, 0], quats=q1[:, 0])
            o3 = model.render(t_i, w2c, Kk, (W_, H_),
                              means=m_c.transpose(0, 1)[i],
                              quats=q_c.transpose(0, 1)[i])
            rend.append({"i": i, "t": t_i,
                         "img_max_abs_diff": float((o1["img"] - o2["img"]).abs().max()),
                         "acc_max_abs_diff": float((o1["acc"] - o2["acc"]).abs().max()),
                         "depth_max_abs_diff": float(
                             (o1.get("depth", o1["img"]) - o2.get("depth", o2["img"])).abs().max())})
            batch_round.append({
                "t": t_i,
                "pose_B1_vs_B8_max": float((m1[:, 0] - m_c.transpose(0, 1)[i]).abs().max()),
                "img_B1_vs_B8_max": float((o2["img"] - o3["img"]).abs().max()),
                "note": "this difference is the einsum reduction order of a B=1 vs "
                        "a B=8 frame batch; it is identical for the frozen path and "
                        "is NOT caused by the residual"})
    check("G1 composed pose == frozen pose bitwise (means)", g1_m == 0.0, {"max": g1_m})
    check("G1b composed pose == frozen pose bitwise (quats)", g1_q == 0.0, {"max": g1_q})
    g2 = max(max(r["img_max_abs_diff"], r["acc_max_abs_diff"]) for r in rend)
    check("G2 initial render bit-identical to the frozen model (same batch size)",
          g2 == 0.0, {"renders": rend})
    gate["G1_pose_identity"] = {"means_max": g1_m, "quats_max": g1_q}
    gate["G2_render_identity"] = rend
    gate["G2b_batch_reduction_note"] = batch_round

    # ------------------------------------------------------------------- G3/G4
    def parity(tag, mode):
        out = []
        for bi, bb in enumerate(batches):
            b1, b2, b3 = clone_batch(bb), clone_batch(bb), clone_batch(bb)
            before = clone_batch(b3)
            K.zero_grads(model)
            loss_f1, stats, _, _ = trainer.compute_losses(b1)
            loss_f1.backward()
            gf1 = grad_snapshot(model)
            K.zero_grads(model)
            loss_f2, _, _, _ = trainer.compute_losses(b2)
            loss_f2.backward()
            gf2 = grad_snapshot(model)
            K.zero_grads(model)
            loss_m, terms, extra, need = K.assemble(model, res, b3, mode)
            # the native part is summed on its own (not by subtracting the
            # regulariser from the total) so the comparison is exact
            native_part = float(K.weighted_total(terms).detach())
            loss_m.backward()
            gm = grad_snapshot(model)
            mutated = same_batch(before, b3)
            gc = grad_cmp(gf1, gf2, gm)
            terms_vs_stats = {}
            for k, v in terms.items():
                st_k = {"rgb": "train/rgb_loss", "mask": "train/mask_loss",
                        "depth_reg": "train/depth_loss",
                        "depth_grad": "train/depth_gradient_loss",
                        "depth_const": "train/mapped_depth_loss",
                        "track": "train/track_2d_loss"}.get(k)
                if st_k and st_k in stats:
                    terms_vs_stats[k] = {
                        "mine": float(v.detach()), "frozen": float(stats[st_k]),
                        "abs": abs(float(v.detach()) - float(stats[st_k]))}
            out.append({
                "batch": bi, "mode": mode, "targets_mutated": mutated,
                "loss_frozen": float(loss_f1.detach()),
                "loss_mine_total": float(loss_m.detach()),
                "loss_mine_native_part": native_part,
                "extra_regulariser": float(extra.detach()) if extra is not None else 0.0,
                "loss_abs_diff": abs(float(loss_f1.detach()) - native_part),
                "frozen_self_loss_diff": abs(float(loss_f1.detach())
                                             - float(loss_f2.detach())),
                "terms_vs_frozen_stats": terms_vs_stats,
                "grad": {k: gc[k] for k in ("bad", "worst_ratio", "worst_param",
                                            "max_self_noise", "max_mine_diff")},
                "grad_per_param": gc["per_param"],
                "resid_grad_norm": ({
                    "coef": float(gm["parm_resid.coef"].norm()) if gm.get("parm_resid.coef") is not None else 0.0,
                    "basis": float(gm["parm_resid.basis"].norm()) if gm.get("parm_resid.basis") is not None else 0.0}
                    if mode == "K" else None),
                "frozen_train_stats": {k: float(v) for k, v in stats.items()
                                       if isinstance(v, (int, float))},
            })
            K.zero_grads(model)
        return out

    p_a0 = parity("A0", "A0")
    g3_loss = max(r["loss_abs_diff"] for r in p_a0)
    g3_bad = sorted({n for r in p_a0 for n in r["grad"]["bad"]})
    g3_self = max(r["grad"]["max_self_noise"] for r in p_a0)
    check("G3 A0 loss reproduces frozen Trainer.compute_losses (bitwise)",
          all(r["loss_abs_diff"] == 0.0 for r in p_a0),
          {"abs": [r["loss_abs_diff"] for r in p_a0]})
    check("G3b A0 gradients agree with frozen gradients within the rasteriser's "
          "own nondeterminism floor (frozen-vs-frozen measured on the same batch)",
          not g3_bad, {"params_outside_floor": g3_bad,
                       "max_self_noise_rel": g3_self,
                       "max_mine_diff_rel": max(r["grad"]["max_mine_diff"]
                                                for r in p_a0),
                       "worst_ratio": max(r["grad"]["worst_ratio"] for r in p_a0)})
    tdiff = max([v["abs"] for r in p_a0 for v in r["terms_vs_frozen_stats"].values()]
                or [0.0])
    check("G3c every logged loss term matches the frozen log_dict values (bitwise)",
          tdiff == 0.0, {"max_abs_term_diff": tdiff})

    p_k = parity("K", "K")
    g4_loss = max(r["loss_abs_diff"] for r in p_k)
    g4_bad = sorted({n for r in p_k for n in r["grad"]["bad"]
                     if not n.startswith("parm_resid.")})
    g4_resid = all((r["resid_grad_norm"]["coef"] > 0 or r["resid_grad_norm"]["basis"] > 0)
                   for r in p_k)
    check("G4 K at delta=0 reproduces the frozen native loss (residual adds only "
          "its declared regulariser)", g4_loss == 0.0,
          {"abs": [r["loss_abs_diff"] for r in p_k],
           "extra_regulariser": [r["extra_regulariser"] for r in p_k]})
    check("G4b K at delta=0 reproduces the frozen native gradients (inside the "
          "noise floor); only the residual itself carries the regulariser's "
          "gradient", not g4_bad and g4_resid,
          {"params_outside_floor": g4_bad, "resid_receives_grad": g4_resid})
    gate["parity"] = {"A0": p_a0, "K": p_k}

    # --------------------------------------------------------------------- G5
    sep = {"step": "CVPR_METHOD_PARM01", "stage": "p02_gpu_graph_routing",
           "note": "structural autograd reachability on the REAL renderer and "
                   "REAL data (torch.autograd.grad allow_unused)", "passes": []}
    base_set = set(K.BASE_MOTION)
    app_set = set(K.APPEARANCE)
    res_set = set(K.RESID_PARAMS)
    for mode, expect, label in (
            ("D_prior", base_set, "D prior pass"),
            ("D_photo", app_set | res_set, "D photo pass"),
            ("K", base_set | res_set | app_set, "K joint pass"),
            ("A0", base_set | app_set, "A0 pass")):
        b2 = clone_batch(batches[0])
        before = clone_batch(b2)
        K.zero_grads(model)
        loss, terms, extra, need = K.assemble(model, res, b2, mode)
        st = K.structural_reach(model, loss)
        get = set(st["present"])
        rec = {"mode": mode, "label": label,
               "expected": sorted(expect), "present": st["present"],
               "absent": st["absent"],
               "structural_norm_by_class": st["norm_by_class"],
               "equals_design": get == expect,
               "forbidden_present": sorted(get - expect),
               "missing": sorted(expect - get),
               "targets_mutated": same_batch(before, b2),
               "graph": K.graph_reachable_params(loss)}
        sep["passes"].append(rec)
        del loss, terms, extra
        K.zero_grads(model)
        torch.cuda.empty_cache()

    for rec in sep["passes"]:
        check(f"G5 {rec['label']}: reachable set == design", rec["equals_design"],
              {"forbidden": rec["forbidden_present"], "missing": rec["missing"]})
        check(f"G6 {rec['label']}: supervision targets untouched",
              rec["targets_mutated"] is None,
              {"mutated": rec["targets_mutated"]})
    gate["reachability"] = sep

    # --------------------------------------------------------------------- G7
    def smoke(mode, steps=3):
        K.zero_grads(model)
        p0 = {n: p.detach().clone() for n, p in model.named_parameters()
              if p.requires_grad}
        gs_before = int(trainer.global_step)
        t0 = time.time()
        terms_log = []
        for i in range(steps):
            b2 = clone_batch(batches[i % len(batches)])
            rec = train_step(mode, b2)
            terms_log.append(rec)
        torch.cuda.synchronize()
        dt = (time.time() - t0) / steps
        moved = {n: float((p.detach() - p0[n]).abs().max())
                 for n, p in model.named_parameters() if n in p0}
        return {"mode": mode, "steps": steps, "s_per_step": dt,
                "global_step_delta": int(trainer.global_step) - gs_before,
                "max_abs_param_change": {k: v for k, v in moved.items()},
                "n_params_changed": sum(1 for v in moved.values() if v > 0),
                "losses": [r["loss"] for r in terms_log],
                "finite": all(np.isfinite(r["loss"]) for r in terms_log)}

    def train_step(mode, b):
        """One PARM01 update: routing depends on the arm (see module docstring)."""
        info = {}
        if mode == "K":
            loss, terms, extra, need = K.assemble(model, res, b, "K")
            loss.backward()
            info = {"loss": float(loss.detach()),
                    "terms": {k: float(v.detach()) for k, v in terms.items()}}
        else:
            l1, t1, _, _ = K.assemble(model, res, b, "D_prior")
            l1.backward()
            l2, t2, _, _ = K.assemble(model, res, b, "D_photo")
            l2.backward()
            info = {"loss": float(l1.detach()) + float(l2.detach()),
                    "loss_prior": float(l1.detach()),
                    "loss_photo": float(l2.detach()),
                    "terms": {k: float(v.detach()) for k, v in t1.items()},
                    "terms_photo": {k: float(v.detach()) for k, v in t2.items()}}
        n_opt = 0
        for opt in trainer.optimizers.values():
            opt.step()
            opt.zero_grad(set_to_none=True)
            n_opt += 1
        for sch in trainer.scheduler.values():
            sch.step()
        trainer.global_step += 1
        info["n_optimizer_steps_called"] = n_opt
        return info

    with torch.no_grad():
        pass
    sm = {"K": smoke("K"), "D": smoke("D")}
    for k, v in sm.items():
        check(f"G7 {k} smoke: finite loss, params move, global_step +={v['steps']}",
              v["finite"] and v["global_step_delta"] == v["steps"]
              and v["n_params_changed"] > 0,
              {kk: v[kk] for kk in ("s_per_step", "global_step_delta",
                                    "n_params_changed", "losses")})
    gate["smoke"] = sm
    gate["peak_vram_gib_gate"] = float(torch.cuda.max_memory_allocated() / 2 ** 30)

    # cost projection
    s_k = sm["K"]["s_per_step"]
    s_d = sm["D"]["s_per_step"]
    s_prefix = float(K.jload(f"{K.W}/PAPER_CVPR_CORE01/runs/Truck_A/run.json")
                     ["median_s_per_step"])
    proj = {
        "prefix_steps": K.FORK_STEP, "prefix_s_per_step_frozen_native": s_prefix,
        "prefix_s": K.FORK_STEP * s_prefix,
        "arm_steps": K.N_STEPS,
        "A0_s": K.N_STEPS * s_prefix, "K_s": K.N_STEPS * s_k,
        "D_s": K.N_STEPS * s_d,
        "gate_s": time.time() - t_loaded,
        "eval_s_est": 300.0,
    }
    proj["total_s"] = (proj["prefix_s"] + proj["A0_s"] + proj["K_s"]
                       + proj["D_s"] + proj["eval_s_est"])
    proj["total_gpu_hours"] = proj["total_s"] / 3600.0
    gate["cost_projection"] = proj
    check("G7b projected end-to-end cost inside the 4 GPU-hour budget",
          proj["total_gpu_hours"] <= 4.0,
          {"projected_gpu_hours": proj["total_gpu_hours"], **{
              k: proj[k] for k in ("prefix_s", "A0_s", "K_s", "D_s")}})

    verdict = "GO" if not FAIL else "STOP"
    gate.update({"verdict": verdict, "n_failed": len(FAIL), "failed": FAIL,
                 "wall_s": time.time() - t_loaded})
    K.jdump(gate, f"{S}/PARM01_GATE_AND_METRICS.json")
    prev = K.jload(f"{S}/PARM01_GRADIENT_SEPARATION_AUDIT.json")
    prev["gpu"] = sep
    K.jdump(prev, f"{S}/PARM01_GRADIENT_SEPARATION_AUDIT.json")
    print("P02_GATE " + json.dumps({"verdict": verdict, "n_failed": len(FAIL),
                                    "projected_gpu_hours":
                                        proj["total_gpu_hours"]}), flush=True)
    return 0 if verdict == "GO" else 4


if __name__ == "__main__":
    sys.exit(main())
