"""CVPR-METHOD-PARM01 step 4a: evaluator identity check.

The frozen evaluators cannot render a residual (K/D) checkpoint, so PARM01 uses
p06_eval.py, which reproduces their metric code and adds only the residual
composition.  This script proves the reproduction by running p06_eval.py on the
residual-free checkpoints and comparing, number by number, against the archived
frozen evaluator outputs.

Compares every summary scalar and every per-frame scalar, and fails on any
difference of any size.

One deliberate exclusion, declared here and nowhere else: the four wall-clock
scalars (`render_s_mean`, `render_s_median`, `render_s_total`, `model_load_s`)
are timings, not metrics.  They are reported separately as `timing_non_metric`
and are NOT allowed to affect the verdict; every metric scalar (PSNR, LPIPS,
counts, quarters, temporal bins) and every per-frame value must still be exactly
equal, to the last bit.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parm_common as K

S = K.S
TIMING_KEYS = ("render_s_mean", "render_s_median", "render_s_total",
               "model_load_s")
PAIRS = [
    ("A_NATIVE", "novel", K.FROZEN_A_EVAL),
    ("A_NATIVE", "train", f"{K.W}/CVPR_METHOD_SRR01/evals/Truck/train_A_NATIVE.json"),
    ("E_EARLY_ONLY", "novel", K.FROZEN_E_EVAL),
    ("E_EARLY_ONLY", "train",
     f"{K.W}/CVPR_METHOD_SRR01/evals/Truck/train_E_EARLY_ONLY.json"),
]


def flatten(d, prefix=""):
    out = {}
    for k, v in d.items():
        if isinstance(v, dict):
            out.update(flatten(v, f"{prefix}{k}."))
        elif isinstance(v, list):
            for i, x in enumerate(v):
                if isinstance(x, (int, float, str)):
                    out[f"{prefix}{k}[{i}]"] = x
        elif isinstance(v, (int, float, str)):
            out[f"{prefix}{k}"] = v
    return out


def main():
    rep = {"step": "CVPR_METHOD_PARM01", "stage": "evaluator_identity",
           "method": "p06_eval.py (residual-aware) vs archived frozen-evaluator "
                     "JSON on residual-free checkpoints", "pairs": [],
           "timing_keys_excluded_from_verdict": list(TIMING_KEYS),
           "exclusion_rule": "wall-clock scalars are reported as timing_non_metric "
                             "and never decide the verdict; every metric scalar and "
                             "every per-frame value must be exactly equal"}
    fail = 0
    for arm, mode, ref_path in PAIRS:
        mine_path = (f"{S}/evals/Truck/{arm}.json" if mode == "novel"
                     else f"{S}/evals/Truck/train_{arm}.json")
        if not (os.path.exists(mine_path) and os.path.exists(ref_path)):
            rep["pairs"].append({"arm": arm, "mode": mode, "status": "MISSING_FILE",
                                 "mine": mine_path, "ref": ref_path})
            fail += 1
            continue
        mine = json.load(open(mine_path))
        ref = json.load(open(ref_path))
        fm, fr = flatten(mine["summary"]), flatten(ref["summary"])
        scal_all = [k for k in fr if isinstance(fr[k], (int, float))
                    and not isinstance(fr[k], bool)]
        scal = [k for k in scal_all if k.split(".")[-1] not in TIMING_KEYS]
        timing = {}
        for k in scal_all:
            if k.split(".")[-1] in TIMING_KEYS:
                timing[k] = {"mine": fm.get(k), "ref": fr[k],
                             "abs": (abs(float(fm[k]) - float(fr[k]))
                                     if k in fm else None),
                             "excluded_reason": "wall clock, not a metric"}
        diffs = {}
        for k in scal:
            if k not in fm:
                diffs[k] = "missing_in_mine"
                continue
            d = abs(float(fm[k]) - float(fr[k]))
            if d != 0.0:
                diffs[k] = {"mine": fm[k], "ref": fr[k], "abs": d}
        pf = {}
        if "per_frame" in ref and "per_frame" in mine:
            rm = {r["frame"]: r for r in mine["per_frame"]}
            for r in ref["per_frame"]:
                m = rm.get(r["frame"])
                if m is None:
                    pf[r["frame"]] = "missing_frame"
                    continue
                for k, v in r.items():
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        d = abs(float(m.get(k, float("nan"))) - float(v))
                        if d != 0.0 and not (d != d):
                            pf.setdefault(r["frame"], {})[k] = d
        ok = not diffs and not pf
        fail += 0 if ok else 1
        rep["pairs"].append({
            "arm": arm, "mode": mode, "mine": mine_path, "ref": ref_path,
            "n_metric_summary_scalars_compared": len(scal),
            "n_timing_scalars_excluded": len(timing),
            "summary_diffs": diffs,
            "timing_non_metric": timing,
            "n_per_frame_rows": len(ref.get("per_frame", [])),
            "per_frame_diffs": pf if pf else {},
            "identical": bool(ok),
        })
        print(("PASS " if ok else "FAIL ") + f"evaluator identity {arm}/{mode} "
              f"({len(scal)} metric summary scalars, {len(timing)} timing scalars "
              f"excluded, {len(ref.get('per_frame', []))} frames)", flush=True)
    rep["n_failed"] = fail
    rep["verdict"] = "IDENTICAL" if fail == 0 else "DIFFERS"
    K.jdump(rep, f"{S}/PARM01_EVALUATOR_IDENTITY.json")
    print("PARM01_EVAL_IDENTITY " + json.dumps({"verdict": rep["verdict"],
                                                "n_failed": fail}), flush=True)
    return 0 if fail == 0 else 4


if __name__ == "__main__":
    sys.exit(main())
