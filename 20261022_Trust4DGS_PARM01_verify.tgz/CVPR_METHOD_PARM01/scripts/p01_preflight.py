"""CVPR-METHOD-PARM01 step 1: CPU pre-flight authenticity + separation gate.

CPU ONLY.  No CUDA is touched (run with CUDA_VISIBLE_DEVICES="").

This step answers one question before any GPU second is spent:

    can the required supervision-path separation actually be BUILT, with the
    residual exactly identity at initialisation, on top of the frozen SoM model,
    without changing any frozen file?

It checks, in this order:

  A. FROZEN STATE READ
     SoM SE(3)/6D motion bases and per-Gaussian foreground motion coefficients,
     the RGB/Depth/Track/Mask loss set and weights actually recorded for the
     native Truck run, the renderer entry points and the optimizer set, and the
     global_step of the fork.  Everything read-only, every file SHA256'd.

  B. COMPOSITION IDENTITY  (T_render = T_prior o Exp(delta), delta = 0)
     * Exp(0) is the exact identity matrix (bitwise), for the real shapes.
     * the composed pose is bitwise equal to the frozen pose at init, on the
       frozen checkpoint, for both training timestamps and target timestamps.
     * the residual is NOT degenerate: d pose / d(coef) != 0 at init.

  C. TRUE GRAPH SEPARATION  (not requires_grad bookkeeping)
     For every arm the autograd DAG of the assembled loss is walked and the
     parameter set actually reachable is compared against the design:
        D prior pass  : reachable == base motion only
        D photo pass  : reachable == residual + appearance only (base excluded)
        K joint pass  : reachable == base motion + residual + appearance
     A differentiable stand-in renderer is used here (gsplat needs CUDA), so this
     tests OUR routing code, which is what the separation is a property of; the
     real-renderer repeat of C plus the exact-parity check of the loss values and
     gradients against frozen Trainer.compute_losses is done in p02 (GPU) and the
     training runs are refused unless it passes.

  D. SUPERVISION TARGETS ARE NOT TOUCHED BY THE RESIDUAL
     depth / track / mask targets are byte-identical before and after each pass.

  E. CAMERA / TOPOLOGY / TIME IDENTITY, and capacity accounting (K == D).

Writes PARM01_METHOD_IDENTITY.json, PARM01_GRADIENT_SEPARATION_AUDIT.json
(cpu section) and PARM01_PREFLIGHT_GATE.json; exits non-zero on STOP.
"""
import json
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parm_common as K

S = K.S
FAIL = []
CHECKS = []


def check(name, ok, detail=None):
    rec = {"check": name, "ok": bool(ok)}
    if detail is not None:
        rec["detail"] = detail
    CHECKS.append(rec)
    if not ok:
        FAIL.append(rec)
    print(("PASS " if ok else "FAIL ") + name
          + ("" if detail is None else "  " + json.dumps(detail, default=float)),
          flush=True)
    return rec


class MockRender:
    """Differentiable CPU stand-in for SceneModel.render (same signature).

    It is a pure function of the tensors the frozen loss code feeds into the
    rasteriser, so the autograd DAG it builds has exactly the same parameter
    reachability as the real renderer would.  Values are meaningless by design.
    """

    OUT_KEYS = ("img", "acc", "mask", "depth", "tracks_3d", "rend_normal",
                "surf_normal")

    def __init__(self, model, H, W):
        self.model = model
        self.H, self.W = H, W

    def __call__(self, t, w2cs, Ks, img_wh, target_ts=None, target_w2cs=None,
                 bg_color=None, colors_override=None, means=None, quats=None,
                 target_means=None, return_color=True, return_depth=False,
                 return_mask=False, fg_only=False, filter_mask=None):
        H, Wd = self.H, self.W
        C = w2cs.shape[0]
        if means is None:
            means, quats = self.model.compute_poses_all(
                torch.tensor([t]) if t is not None else None)
            means, quats = means[:, 0], quats[:, 0]
        colors = self.model.get_colors_all()
        scales = self.model.get_scales_all()
        opac = self.model.get_opacities_all()
        g = (means.reshape(-1, 3).mean(0) + quats.reshape(-1, 4)[:, :3].mean(0)
             + scales.mean(0) + colors.mean(0))
        base = g.view(1, 3, 1, 1).expand(C, 3, H, Wd)
        out = {}
        out["img"] = base.permute(0, 2, 3, 1).contiguous()
        out["acc"] = (opac.mean() + 0.0 * means.mean()).view(1, 1, 1, 1).repeat(
            C, H, Wd, 1)
        out["mask"] = (colors.mean() + 0.0 * means.mean()).view(1, 1, 1, 1).repeat(
            C, H, Wd, 1)
        out["depth"] = out["img"].mean(-1, keepdim=True)
        if target_ts is not None and target_means is not None:
            N = target_ts.shape[0]
            tv = target_means.reshape(-1, N, 3).mean(0)            # (N,3)
            out["tracks_3d"] = tv.view(1, 1, 1, N, 3).repeat(C, H, Wd, 1, 1)
        else:
            out["tracks_3d"] = None
        out["rend_normal"] = None
        out["surf_normal"] = None
        del return_color, return_depth, return_mask, fg_only, filter_mask, \
            colors_override, bg_color, Ks, target_w2cs
        return {k: out[k] for k in self.OUT_KEYS}


class MockModel:
    """Unused helper retained only to document the wrapper shape.

    p01 monkeypatches `model.render` with MockRender instead, so that the REAL
    frozen parameter containers and the REAL geometry code are exercised.
    """

    def __init__(self, model, H, W):
        self._m = model
        self.fg = model.fg
        self.bg = model.bg
        self.motion_bases = model.motion_bases
        self.training = True
        self.render = MockRender(model, H, W)

    def __getattr__(self, k):
        return getattr(self._m, k)


def synth_batch(B=2, N=2, H=8, W=8, P=4, seed=7):
    g = torch.Generator().manual_seed(seed)
    ts = torch.tensor([3, 11][:B])
    tgt = [torch.tensor([5, 9][:N]), torch.tensor([2, 13][:N])][:B]
    qp = torch.tensor([[1, 1], [3, 2], [5, 4], [6, 6]][:P], dtype=torch.float32)
    return {
        "ts": ts,
        "w2cs": torch.eye(4).repeat(B, 1, 1),
        "Ks": torch.eye(3).repeat(B, 1, 1),
        "imgs": torch.rand(B, H, W, 3, generator=g),
        "valid_masks": torch.ones(B, H, W),
        "masks": (torch.rand(B, H, W, generator=g) > 0.5).float(),
        "depths": 1.0 + torch.rand(B, H, W, generator=g),
        "query_tracks_2d": [qp.clone() for _ in range(B)],
        "target_ts": tgt,
        "target_w2cs": [torch.eye(4).repeat(N, 1, 1) for _ in range(B)],
        "target_Ks": [torch.eye(3).repeat(N, 1, 1) for _ in range(B)],
        "target_tracks_2d": [torch.rand(N, P, 2, generator=g) for _ in range(B)],
        "target_visibles": [torch.ones(N, P, dtype=torch.bool) for _ in range(B)],
        "target_invisibles": [torch.zeros(N, P, dtype=torch.bool) for _ in range(B)],
        "target_confidences": [torch.ones(N, P) for _ in range(B)],
        "target_track_depths": [1.0 + torch.rand(N, P, generator=g) for _ in range(B)],
    }


def clone_batch(b):
    out = {}
    for k, v in b.items():
        if torch.is_tensor(v):
            out[k] = v.clone()
        elif isinstance(v, list):
            out[k] = [x.clone() for x in v]
        else:
            out[k] = v
    return out


def same_batch(a, b):
    for k in a:
        va, vb = a[k], b[k]
        if torch.is_tensor(va):
            if not torch.equal(va, vb):
                return k
        elif isinstance(va, list):
            for x, y in zip(va, vb):
                if not torch.equal(x, y):
                    return k
        elif va != vb:
            return k
    return None


def main():
    os.makedirs(f"{S}/logs", exist_ok=True)
    # The frozen Trainer.init_from_checkpoint calls torch.load() WITHOUT
    # map_location, which cannot run on a CPU-only process.  Test harness shim
    # (no frozen file is modified): force CPU mapping for the duration of p01.
    _orig_load = torch.load

    def _cpu_load(*a, **kw):
        kw.setdefault("map_location", "cpu")
        return _orig_load(*a, **kw)

    torch.load = _cpu_load
    identity = {"step": "CVPR_METHOD_PARM01", "stage": "p01_cpu_preflight"}
    sep = {"step": "CVPR_METHOD_PARM01", "stage": "p01_cpu_graph_routing",
           "note": "structural autograd-DAG reachability, CPU mock renderer"}

    # ---------------------------------------------------------------- A
    identity["frozen_files"] = {
        p: K.sha256_file(p) for p in (
            K.INIT_CKPT, K.FROZEN_A_CKPT, K.FROZEN_E_CKPT, K.PS_STAGE,
            f"{K.W}/Trust4DGS_Portable/RouteA_Transfer/repo/third_party/"
            f"shape_of_motion/flow3d/trainer.py",
            f"{K.W}/Trust4DGS_Portable/RouteA_Transfer/repo/third_party/"
            f"shape_of_motion/flow3d/scene_model.py",
            f"{K.W}/Trust4DGS_Portable/RouteA_Transfer/repo/third_party/"
            f"shape_of_motion/flow3d/params.py",
            f"{K.W}/Trust4DGS_Portable/RouteA_Transfer/repo/third_party/"
            f"shape_of_motion/flow3d/loss_utils.py",
            f"{K.W}/METHOD01_CAPE4D/scripts/cape_common.py",
            f"{K.W}/PAPER_METHOD_STAGE02/scripts/ps02_eval.py",
            f"{K.W}/PAPER_CORE_BASELINE_REALISM/scripts/pc_eval_train.py")}

    trainers = {}
    tr, _ = K.build_trainer(K.FROZEN_A_CKPT, torch.device("cpu"),
                            f"{S}/cache/_p01_reload", trainable=True)
    trainers["frozen_A"] = tr
    model = tr.model
    G, T = model.num_fg_gaussians, model.num_frames
    Kb = model.num_motion_bases
    frozen_run = K.jload(f"{K.W}/PAPER_CVPR_CORE01/runs/Truck_A/run.json")
    identity["frozen_state"] = {
        "ckpt": K.FROZEN_A_CKPT, "global_step": int(
            torch.load(K.FROZEN_A_CKPT, map_location="cpu",
                       weights_only=False)["global_step"]),
        "num_motion_bases": int(Kb), "num_frames": int(T),
        "num_fg": int(G), "num_bg": int(model.num_bg_gaussians),
        "motion_bases_rots": list(model.motion_bases.params["rots"].shape),
        "motion_bases_transls": list(model.motion_bases.params["transls"].shape),
        "fg_motion_coefs": list(model.fg.params["motion_coefs"].shape),
        "coef_activation": "softmax over K (params.GaussianParams.get_coefs)",
        "rotation_param": "cont_6d_to_rmat over the coefficient-blended 6D",
        "renderer": "flow3d.scene_model.SceneModel.render -> gsplat.rasterization",
        "loss_weights_native_run": frozen_run["loss_weights"],
        "loss_weights_module": dict(K.NATIVE_W),
        "optimizer_keys_native": sorted(frozen_run.get("optim_cfg", {}).keys()),
        "fork_step": K.FORK_STEP, "total_native_steps": K.TOTAL_STEPS,
        "density_control_stops_at": int(frozen_run["optim_cfg"]["stop_control_steps"]),
        "topology_frozen_after_fork": bool(
            frozen_run["optim_cfg"]["stop_control_steps"] <= K.FORK_STEP),
    }
    check("A1 fork_step >= stop_control_steps (topology frozen in all arms)",
          K.FORK_STEP >= int(frozen_run["optim_cfg"]["stop_control_steps"]))
    check("A2 native loss weights match the frozen Truck_A run",
          all(abs(frozen_run["loss_weights"][k] - v) < 1e-12
              for k, v in K.NATIVE_W.items()), frozen_run["loss_weights"])
    check("A3 fg motion coefficients are per-Gaussian over K bases",
          list(model.fg.params["motion_coefs"].shape) == [G, Kb])

    # ---------------------------------------------------------------- B
    res = K.attach_residual(trainers["frozen_A"])
    ts = torch.tensor([3, 11, 40, 199])
    tvec = torch.tensor([5, 9, 2, 13, 44, 180])
    with torch.no_grad():
        dT = res.transforms(ts)
        eye = torch.eye(4)[:3].unsqueeze(0).unsqueeze(0)
        err_I = float((dT - eye).abs().max())
        T0 = K.base_transforms(model, ts)
        Tt0 = K.base_transforms(model, tvec)
        Tc = K.compose(T0, dT)
        err_comp = float((Tc - T0).abs().max())
        m_frozen, q_frozen = K.pose_from_transforms(model, T0)
        m_ref, q_ref = model.compute_poses_all(ts)
        err_m = float((m_frozen - m_ref).abs().max())
        err_q = float((q_frozen - q_ref).abs().max())
        mt_c, _ = K.pose_from_transforms(model, K.compose(
            Tt0, res.transforms(tvec)))
        mt_ref, _ = model.compute_poses_all(tvec)
        err_mt = float((mt_c - mt_ref).abs().max())
        rot_only = float((K.se3_exp(torch.zeros(4, 6))[0]
                          - torch.eye(3)).abs().max())
        trans_only = float(K.se3_exp(torch.zeros(4, 6))[1].abs().max())
        # Exp correctness against the ground truth SE(3) matrix exponential
        g = torch.Generator().manual_seed(3)
        xi = torch.randn(64, 6, generator=g) * 0.3
        Rr, tr_ = K.se3_exp(xi)
        M = torch.zeros(64, 4, 4)
        M[:, :3, :3] = K._so3_hat(xi[:, :3])
        M[:, :3, 3] = xi[:, 3:]
        E = torch.matrix_exp(M)
        err_exp = float((Rr - E[:, :3, :3]).abs().max())
        err_vexp = float((tr_ - E[:, :3, 3]).abs().max())

    check("B1 residual transform is exactly identity at init", err_I == 0.0,
          {"max_abs_dev_from_I": err_I})
    check("B2 T_prior o Exp(0) == T_prior bitwise", err_comp == 0.0,
          {"max_abs_dev": err_comp})
    check("B3 composed pose == frozen pose bitwise (means)", err_m == 0.0,
          {"max_abs_dev": err_m})
    check("B4 composed pose == frozen pose bitwise (quats)", err_q == 0.0,
          {"max_abs_dev": err_q})
    check("B5 composed target-time pose == frozen bitwise", err_mt == 0.0,
          {"max_abs_dev": err_mt})
    check("B6 Exp(0) rotation block exactly I / translation exactly 0",
          rot_only == 0.0 and trans_only == 0.0)
    check("B7 Exp rotation block matches torch.matrix_exp (SE(3) truth)",
          err_exp < 1e-5, {"max_abs_dev": err_exp})
    check("B8 Exp translation uses the left Jacobian (matches matrix_exp)",
          err_vexp < 1e-5, {"max_abs_dev": err_vexp})

    # residual must be learnable at init (non-degenerate)
    K.zero_grads(model)
    m1, _ = K.pose_from_transforms(model, K.compose(
        K.base_transforms(model, ts), res.transforms(ts)))
    (m1 ** 2).sum().backward()
    gc = float(res.coef.grad.abs().max()) if res.coef.grad is not None else 0.0
    saved = res.coef.detach().clone()
    with torch.no_grad():
        res.coef.add_(0.01)
    K.zero_grads(model)
    m2, _ = K.pose_from_transforms(model, K.compose(
        K.base_transforms(model, ts), res.transforms(ts)))
    (m2 ** 2).sum().backward()
    gb = float(res.basis.grad.abs().max()) if res.basis.grad is not None else 0.0
    with torch.no_grad():
        res.coef.copy_(saved)
    check("B9 d(pose)/d(residual coef) != 0 at init", gc > 0.0, {"max|grad|": gc})
    check("B10 d(pose)/d(residual basis) != 0 once coef is non-zero "
          "(structurally zero at exactly coef=0: xi = a * basis)", gb > 0.0,
          {"max|grad|": gb})
    K.zero_grads(model)

    identity["residual"] = dict(K.RESID)
    identity["residual"]["n_params"] = int(res.n_params())
    identity["residual"]["n_params_coef"] = int(res.coef.numel())
    identity["residual"]["n_params_basis"] = int(res.basis.numel())
    native_motion = int(model.fg.params["motion_coefs"].numel()
                        + model.motion_bases.params["rots"].numel()
                        + model.motion_bases.params["transls"].numel())
    identity["residual"]["native_motion_params"] = native_motion
    identity["residual"]["n_fg_gaussians"] = int(G)
    check("B11 residual capacity is small relative to native motion capacity",
          res.n_params() < 0.5 * native_motion,
          {"residual": int(res.n_params()), "native_motion": native_motion,
           "ratio": res.n_params() / native_motion})
    identity["identity_errors"] = {
        "residual_is_I": err_I, "compose_noop": err_comp,
        "pose_means": err_m, "pose_quats": err_q, "pose_targets": err_mt,
        "exp_vs_roma": err_exp, "exp_translation": err_vexp}

    # ---------------------------------------------------------------- C/D
    H = Wd = 8
    model.render = MockRender(model, H, Wd)     # CUDA-free stand-in rasteriser
    batch0 = synth_batch(H=H, W=Wd)

    def run_mode(tag, mode):
        b = clone_batch(batch0)
        before = clone_batch(b)
        K.zero_grads(model)
        loss, terms, extra, need = K.assemble(model, res, b, mode)
        st = K.structural_reach(model, loss)
        reach = st["present"]
        loss.backward()
        gn = K.grad_norms(model)
        mutated = same_batch(before, b)
        res_rec = {
            "arm_pass": tag, "mode": mode, "need": sorted(need),
            "loss_value": float(loss.detach()),
            "unweighted_terms": {k: float(v.detach()) for k, v in terms.items()},
            "reachable_params": reach,
            "unreachable_params": st["absent"],
            "structurally_present_classes": st["present_by_class"],
            "structural_grad_norm_by_class": st["norm_by_class"],
            "backward_grad_norm_by_class": gn,
            "graph_nodes": K.graph_reachable_params(loss)["n_graph_nodes"],
            "batch_targets_mutated": mutated,
        }
        K.zero_grads(model)
        return reach, gn, mutated, res_rec

    def set_of(names):
        return set(names)

    base_set = set_of(K.BASE_MOTION)
    app_set = set_of(K.APPEARANCE)
    res_set = set_of(K.RESID_PARAMS)

    audits = []
    r_Dp, g_Dp, mut_Dp, rec_Dp = run_mode("D_prior", "D_prior")
    audits.append(rec_Dp)
    check("C1 D prior pass reaches BASE MOTION ONLY",
          set_of(r_Dp) == base_set, {"reachable": sorted(r_Dp)})
    check("C2 D prior pass: no appearance / residual / camera reachable",
          not (set_of(r_Dp) & (app_set | res_set
                               | {"camera_poses.params.Rs", "camera_poses.params.ts"})))
    check("C3 D prior pass: base motion receives non-zero gradient",
          g_Dp.get("base_motion", 0.0) > 0.0, g_Dp)
    check("C4 D prior pass does not mutate supervision targets",
          mut_Dp is None, {"mutated_key": mut_Dp})

    r_Dph, g_Dph, mut_Dph, rec_Dph = run_mode("D_photo", "D_photo")
    audits.append(rec_Dph)
    check("C5 D photo pass reaches RESIDUAL + APPEARANCE ONLY",
          set_of(r_Dph) == (app_set | res_set), {"reachable": sorted(r_Dph)})
    check("C6 D photo pass: base motion structurally ABSENT from the graph",
          not (set_of(r_Dph) & base_set))
    check("C7 D photo pass: residual receives non-zero gradient",
          g_Dph.get("resid", 0.0) > 0.0, g_Dph)
    check("C8 D photo pass does not mutate supervision targets",
          mut_Dph is None, {"mutated_key": mut_Dph})

    r_K, g_K, mut_K, rec_K = run_mode("K_joint", "K")
    audits.append(rec_K)
    check("C9 K joint pass reaches base motion + residual + appearance",
          set_of(r_K) == (base_set | res_set | app_set), {"reachable": sorted(r_K)})
    check("C10 K joint pass gives gradient to all three families",
          all(g_K.get(c, 0.0) > 0.0 for c in
              ("base_motion", "resid", "appearance")), g_K)
    check("C11 K joint pass does not mutate supervision targets",
          mut_K is None, {"mutated_key": mut_K})

    r_A0, g_A0, mut_A0, rec_A0 = run_mode("A0_native", "A0")
    audits.append(rec_A0)
    check("C12 A0 pass (frozen pose path) reaches base motion + appearance, "
          "and the residual is absent (no residual in the A0 graph)",
          set_of(r_A0) == (base_set | app_set), {"reachable": sorted(r_A0)})

    sep["passes"] = audits
    sep["design"] = {
        "D_prior_expected": sorted(base_set),
        "D_photo_expected": sorted(app_set | res_set),
        "K_expected": sorted(base_set | res_set | app_set),
        "A0_expected": sorted(base_set | app_set),
        "sorting_rule": "residual coef zero + no softmax -> Delta = I at init",
        "separation_mechanism": "graph construction: T_base only for the prior "
                                "pass; T_base.detach() for the photometric pass",
    }

    # ---------------------------------------------------------------- E
    cams = {n: bool(p.requires_grad) for n, p in model.named_parameters()
            if n.startswith("camera_poses.")}
    identity["camera_trainable"] = cams
    check("E1 camera parameters are frozen (requires_grad False)",
          not any(cams.values()), cams)
    trainable = sorted(n for n, p in model.named_parameters() if p.requires_grad)
    identity["trainable_native"] = trainable
    check("E2 no unexpected trainable parameters (native set + residual only)",
          set(trainable) == (base_set | app_set | res_set),
          {"trainable": trainable})
    counts = {"num_fg": int(model.num_fg_gaussians),
              "num_bg": int(model.num_bg_gaussians)}
    identity["topology"] = {"counts_frozen_ckpt": counts,
                            "counts_truck_A_final": frozen_run["counts_final"]}
    check("E3 topology counts equal the frozen native final counts "
          "(control stopped before the fork, so the fork state is final)",
          counts["num_fg"] == frozen_run["counts_final"]["num_fg"]
          and counts["num_bg"] == frozen_run["counts_final"]["num_bg"], counts)
    cap = {"K": {"residual": int(res.n_params()),
                 "native_motion": native_motion},
           "D": {"residual": int(res.n_params()),
                 "native_motion": native_motion}}
    identity["capacity"] = cap
    identity["capacity"]["K_equals_D"] = cap["K"] == cap["D"]
    check("E4 K and D residual capacity are identical",
          cap["K"] == cap["D"], cap)

    verdict = "GO" if not FAIL else "STOP"
    gate = {
        "step": "CVPR_METHOD_PARM01", "stage": "p01_cpu_preflight",
        "verdict": verdict, "n_checks": len(CHECKS), "n_failed": len(FAIL),
        "n_passed": len(CHECKS) - len(FAIL),
        "checks_passed": [c["check"] for c in CHECKS if c["ok"]],
        "failed": FAIL,
        "separation_achievable": not any(f["check"].startswith(("C1", "C2", "C5",
                                                                "C6"))
                                         for f in FAIL),
        "note": "PASS here only licenses the GPU identity gate (p02). No arm is"
                " trained before p02 reproduces frozen loss/gradient values and"
                " repeats the reachability test on the real renderer.",
    }
    identity["checks"] = CHECKS
    # keep the GPU section written by p02 if this CPU step is re-run afterwards
    p_sep = f"{S}/PARM01_GRADIENT_SEPARATION_AUDIT.json"
    if os.path.exists(p_sep):
        prev = K.jload(p_sep)
        if "gpu" in prev:
            sep["gpu"] = prev["gpu"]
    K.jdump(gate, f"{S}/PARM01_PREFLIGHT_GATE.json")
    K.jdump(identity, f"{S}/PARM01_METHOD_IDENTITY.json")
    K.jdump(sep, f"{S}/PARM01_GRADIENT_SEPARATION_AUDIT.json")
    print("P01_GATE " + json.dumps({k: gate[k] for k in
                                    ("verdict", "n_failed", "separation_achievable")}),
          flush=True)
    return 0 if verdict == "GO" else 4


if __name__ == "__main__":
    sys.exit(main())
