# PARM01 execution report — Prior-Anchored Residual Motion (Truck, stage 1)

Step `CVPR_METHOD_PARM01`, scene `Truck`, seed 42, GPU `cuda:0` (GPU6 unused). Fork at native global_step 4000, native endpoint 13000.

## 1. Verdict (mechanical)

* Stage-1 label: **`CAPACITY_ONLY_GAIN`**
* gain (D beats capacity-matched K on a gain metric): **False**
* fg_kept: **{"D_minus_A0_fg_psnr": -0.053443768722047945, "D_minus_K_fg_psnr": -0.06921368753005049, "passes": false}**
* no_severe_cost: **{"D_minus_K_band_psnr": -0.18110876206047424, "D_minus_K_halo_psnr": -0.8719212973896868, "late_quarter_fg": {"D": 28.48217316096401, "A0": 28.507474107774293, "K": 28.50035144579345}, "passes": false}**
* Umbrella authorised by this label: **False**

The label is a DEV signal. It is not a CVPR novelty claim and no paper text is produced in this step.

## 2. Gates that had to pass before any training second

* CPU preflight (p01): `GO`, 30/30 checks passed, 0 failures.
* GPU gate (p02): `GO`, 0 failures, projected 1.58 GPU-hours.
* Evaluator identity (p05b): `IDENTICAL`, 0 failures; the excluded wall-clock scalars are `['render_s_mean', 'render_s_median', 'render_s_total', 'model_load_s']`, every metric scalar and every per-frame value is exactly equal.

### 2.1 Identity of the initial render

* residual transform at init: max |Delta - I| = `0.0`
* T_prior o Exp(0) vs T_prior: max dev = `0.0`
* composed pose vs frozen pose: means `0.0`, quats `0.0`
* rendered image / alpha / depth vs frozen model, same batch size: [{"img_max_abs_diff": 0.0, "acc_max_abs_diff": 0.0, "depth_max_abs_diff": 0.0}, {"img_max_abs_diff": 0.0, "acc_max_abs_diff": 0.0, "depth_max_abs_diff": 0.0}]

### 2.2 Frozen-loss parity of the re-implementation

* A0 batch 0: frozen loss `0.022597894`, native part `0.022597894`, |diff| `0.0`; gradient disagreement `4.547522609506008e-06` vs frozen self-noise `4.547522609506008e-06`; native params outside the floor: `[]`; residual params with no frozen counterpart: `[]`
* A0 batch 1: frozen loss `0.020620294`, native part `0.020620294`, |diff| `0.0`; gradient disagreement `2.7860757808559917e-07` vs frozen self-noise `2.701649242042174e-07`; native params outside the floor: `[]`; residual params with no frozen counterpart: `[]`
* K batch 0: frozen loss `0.022597894`, native part `0.022597894`, |diff| `0.0`; gradient disagreement `3.7182724720882616e-07` vs frozen self-noise `4.436607423908301e-07`; native params outside the floor: `[]`; residual params with no frozen counterpart: `['parm_resid.coef', 'parm_resid.basis']`
* K batch 1: frozen loss `0.020620294`, native part `0.020620294`, |diff| `0.0`; gradient disagreement `3.630341168994171e-07` vs frozen self-noise `2.4905828950076294e-07`; native params outside the floor: `[]`; residual params with no frozen counterpart: `['parm_resid.coef', 'parm_resid.basis']`

`gsplat`'s backward is not deterministic (atomic accumulation), so gradient equality is required to be inside the *measured* frozen-vs-frozen floor on the same batch, not bitwise. `parm_resid.*` exists only in the K/D graph, so it can never have a frozen counterpart; the gate's own G3b/G4b checks exclude exactly those names when they decide pass/fail, and the residual's only mandated gradient at delta=0 is the declared regulariser's (`resid_grad_norm` > 0).

### 2.3 Structural supervision-path separation (real renderer, real data)

| pass | reachable == design | forbidden present | missing | targets mutated | graph nodes |
|---|---|---|---|---|---|
| D prior pass | True | [] | [] | None | 3 |
| D photo pass | True | [] | [] | None | 4 |
| K joint pass | True | [] | [] | None | 4 |
| A0 pass | True | [] | [] | None | 3 |

Reachability is measured with `torch.autograd.grad(..., allow_unused=True)` on the actual graph (None = no path), not from `requires_grad` flags and not from post-hoc `.grad` inspection. The CPU preflight repeats the same test with a differentiable stand-in rasteriser (`PARM01_GRADIENT_SEPARATION_AUDIT.json`, cpu section).

## 3. Arms, cost and checkpoints

| arm | updates | global_step | wall_s | s/update | peak VRAM GiB | fg/bg | ckpt sha256 (12) |
|---|---|---|---|---|---|---|---|
| PREFIX | 4000 | 4000 | 883.1 | 0.1379 | 2.05 | 65808/144074 | 93202e44593a |
| A0 | 9000 | 13000 | 2213.5 | 0.1429 | 1.83 | 65808/144074 | 5557dbe9787e |
| K | 9000 | 13000 | 2189.1 | 0.2432 | 2.24 | 65808/144074 | 12c160336b13 |
| D | 9000 | 13000 | 2097.8 | 0.2091 | 1.37 | 65808/144074 | 1205f8470ab0 |

GPU-active training total: **2.051 h** (budget 4.0 h), including the regenerated common prefix.

## 4. Reconstruction results (novel view, frozen metric identities)

| arm | novel_full_psnr | novel_fg_psnr | novel_bg_psnr | novel_band_psnr | novel_halo_psnr | late_quarter_fg_psnr | train_source_fg_psnr | generalisation_gap_fg_psnr | novel_full_lpips | novel_fg_lpips |
|---|---|---|---|---|---|---|---|---|---|---|
| A_NATIVE | 27.8082 | 27.4671 | 27.9395 | 25.3727 | 27.0965 | 28.4580 | 32.2085 | 4.7413 | 0.0500 | 0.0089 |
| E_EARLY_ONLY | 27.7551 | 27.8120 | 27.8377 | 25.5880 | 26.5214 | 28.8429 | 33.7016 | 5.8896 | 0.0503 | 0.0078 |
| A0 | 27.7836 | 27.4891 | 27.9141 | 25.3336 | 27.0747 | 28.5075 | 32.2232 | 4.7340 | 0.0499 | 0.0088 |
| K | 27.8241 | 27.5049 | 27.9575 | 25.4111 | 27.0641 | 28.5004 | 32.9122 | 5.4073 | 0.0495 | 0.0086 |
| D | 27.6979 | 27.4357 | 27.8162 | 25.2300 | 26.1922 | 28.4822 | 32.0920 | 4.6563 | 0.0521 | 0.0095 |

## 5. Capacity-matched ablation (paired, camera-clustered bootstrap)

| contrast | metric | delta | CI | excludes 0 | gain>=margin | frames | clusters |
|---|---|---|---|---|---|---|---|
| D-K | full_psnr | -0.1262 | [-0.1632, -0.0991] | True | False | 612 | 3 |
| D-K | fg_psnr | -0.0692 | [-0.1513, 0.0105] | False | False | 612 | 3 |
| D-K | bg_psnr | -0.1413 | [-0.1753, -0.1094] | True | False | 612 | 3 |
| D-K | band_psnr | -0.1811 | [-0.2218, -0.1366] | True | False | 612 | 3 |
| D-K | halo_psnr | -0.8719 | [-1.0018, -0.7909] | True | False | 612 | 3 |
| D-K | full_lpips | 0.00259 | [0.0023, 0.0030] | True | False | 612 | 3 |
| D-K | fg_lpips | 0.00088 | [0.0009, 0.0009] | True | False | 612 | 3 |
| D-K | bg_lpips | 0.00223 | [0.0019, 0.0027] | True | False | 612 | 3 |
| D-K | band_lpips | 0.00006 | [-0.0000, 0.0002] | False | False | 612 | 3 |
| D-K | halo_lpips | 0.00075 | [0.0007, 0.0008] | True | False | 612 | 3 |
| K-A0 | full_psnr | 0.0405 | [0.0316, 0.0485] | True | True | 612 | 3 |
| K-A0 | fg_psnr | 0.0158 | [0.0021, 0.0296] | True | False | 612 | 3 |
| K-A0 | bg_psnr | 0.0434 | [0.0340, 0.0483] | True | True | 612 | 3 |
| K-A0 | band_psnr | 0.0775 | [0.0710, 0.0820] | True | True | 612 | 3 |
| K-A0 | halo_psnr | -0.0105 | [-0.0265, 0.0031] | False | False | 612 | 3 |
| K-A0 | full_lpips | -0.00037 | [-0.0007, -0.0001] | True | True | 612 | 3 |
| K-A0 | fg_lpips | -0.00017 | [-0.0002, -0.0001] | True | True | 612 | 3 |
| K-A0 | bg_lpips | -0.00014 | [-0.0003, 0.0001] | False | False | 612 | 3 |
| K-A0 | band_lpips | -0.00007 | [-0.0001, -0.0000] | True | True | 612 | 3 |
| K-A0 | halo_lpips | -0.00011 | [-0.0001, -0.0001] | True | True | 612 | 3 |
| D-A0 | full_psnr | -0.0857 | [-0.1218, -0.0506] | True | False | 612 | 3 |
| D-A0 | fg_psnr | -0.0534 | [-0.1357, 0.0126] | False | False | 612 | 3 |
| D-A0 | bg_psnr | -0.0979 | [-0.1275, -0.0611] | True | False | 612 | 3 |
| D-A0 | band_psnr | -0.1036 | [-0.1508, -0.0571] | True | False | 612 | 3 |
| D-A0 | halo_psnr | -0.8825 | [-1.0284, -0.7991] | True | False | 612 | 3 |
| D-A0 | full_lpips | 0.00222 | [0.0022, 0.0023] | True | False | 612 | 3 |
| D-A0 | fg_lpips | 0.00071 | [0.0007, 0.0008] | True | False | 612 | 3 |
| D-A0 | bg_lpips | 0.00209 | [0.0019, 0.0023] | True | False | 612 | 3 |
| D-A0 | band_lpips | -0.00001 | [-0.0001, 0.0001] | False | False | 612 | 3 |
| D-A0 | halo_lpips | 0.00064 | [0.0006, 0.0007] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | full_psnr | -0.0571 | [-0.0667, -0.0464] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | fg_psnr | -0.3763 | [-0.5303, -0.2831] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | bg_psnr | -0.0216 | [-0.0295, -0.0073] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | band_psnr | -0.3580 | [-0.4165, -0.3084] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | halo_psnr | -0.3292 | [-0.3710, -0.3039] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | full_lpips | 0.00184 | [0.0017, 0.0020] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | fg_lpips | 0.00176 | [0.0017, 0.0019] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | bg_lpips | -0.00011 | [-0.0003, -0.0000] | True | True | 612 | 3 |
| D-E_EARLY_ONLY | band_lpips | 0.00041 | [0.0004, 0.0004] | True | False | 612 | 3 |
| D-E_EARLY_ONLY | halo_lpips | 0.00041 | [0.0004, 0.0004] | True | False | 612 | 3 |
| D-A_NATIVE | full_psnr | -0.1103 | [-0.1364, -0.0840] | True | False | 612 | 3 |
| D-A_NATIVE | fg_psnr | -0.0314 | [-0.1119, 0.0524] | False | False | 612 | 3 |
| D-A_NATIVE | bg_psnr | -0.1234 | [-0.1389, -0.0952] | True | False | 612 | 3 |
| D-A_NATIVE | band_psnr | -0.1427 | [-0.1814, -0.0918] | True | False | 612 | 3 |
| D-A_NATIVE | halo_psnr | -0.9043 | [-1.0407, -0.8212] | True | False | 612 | 3 |
| D-A_NATIVE | full_lpips | 0.00209 | [0.0016, 0.0024] | True | False | 612 | 3 |
| D-A_NATIVE | fg_lpips | 0.00064 | [0.0005, 0.0007] | True | False | 612 | 3 |
| D-A_NATIVE | bg_lpips | 0.00203 | [0.0016, 0.0024] | True | False | 612 | 3 |
| D-A_NATIVE | band_lpips | 0.00003 | [-0.0001, 0.0002] | False | False | 612 | 3 |
| D-A_NATIVE | halo_lpips | 0.00072 | [0.0007, 0.0007] | True | False | 612 | 3 |
| A0-A_NATIVE | full_psnr | -0.0247 | [-0.0334, -0.0146] | True | False | 612 | 3 |
| A0-A_NATIVE | fg_psnr | 0.0220 | [0.0024, 0.0399] | True | True | 612 | 3 |
| A0-A_NATIVE | bg_psnr | -0.0255 | [-0.0342, -0.0114] | True | False | 612 | 3 |
| A0-A_NATIVE | band_psnr | -0.0391 | [-0.0518, -0.0307] | True | False | 612 | 3 |
| A0-A_NATIVE | halo_psnr | -0.0219 | [-0.0312, -0.0123] | True | False | 612 | 3 |
| A0-A_NATIVE | full_lpips | -0.00013 | [-0.0006, 0.0001] | False | False | 612 | 3 |
| A0-A_NATIVE | fg_lpips | -0.00007 | [-0.0001, -0.0000] | True | True | 612 | 3 |
| A0-A_NATIVE | bg_lpips | -0.00006 | [-0.0004, 0.0002] | False | False | 612 | 3 |
| A0-A_NATIVE | band_lpips | 0.00004 | [0.0000, 0.0001] | True | False | 612 | 3 |
| A0-A_NATIVE | halo_lpips | 0.00007 | [0.0000, 0.0001] | True | False | 612 | 3 |

Margin 0.02 dB, major cost 0.1 dB, 4000 bootstrap resamples, cluster = camera (3 camera clusters). Two-sided 95% percentile interval over cluster resamples.

## 6. Motion trajectories actually learned

| arm | base drift vs prefix (RMS, frame 102) | canonical mean drift vs prefix | residual displacement (RMS, frame 102) | residual rotation (rad, mean) | |a| mean | frac(a != 0) |
|---|---|---|---|---|---|---|
| A0 | 0.12645 | 0.03936 | n/a | n/a | n/a | n/a |
| K | 0.12966 | 0.03868 | 0.00763 | 0.00943 | 0.20670 | 0.9976 |
| D | 0.22619 | 0.04290 | 0.01330 | 0.01035 | 0.26304 | 0.9905 |

Displacements are in scene units on the canonical Gaussian means, at the sampled frames [0, 51, 102, 153, 203]. A residual that stayed at zero would report exactly 0 for the residual rows.

## 7. What this step does not licence

* No Umbrella run, no extra seed, no new scene: stage 2 is gated on the label above (`CAPACITY_ONLY_GAIN`).
* No paper text, no scientific claim, no change of capacity/weights/rules after the numbers were read.
* K and D ckpts are not loadable by the frozen evaluators (those ignore `parm_resid.*`); the residual-aware evaluator is identity-checked against the frozen outputs on the residual-free arms.

## 8. Files

* `PARM01_PROTOCOL.json`
* `PARM01_METHOD_IDENTITY.json`
* `PARM01_GRADIENT_SEPARATION_AUDIT.json`
* `PARM01_PREFLIGHT_GATE.json`
* `PARM01_GATE_AND_METRICS.json`
* `PARM01_EVALUATOR_IDENTITY.json`
* `PARM01_NATIVE_RECON_RESULTS.csv`
* `PARM01_FOREGROUND_BACKGROUND_TEMPORAL.csv`
* `PARM01_CAPACITY_MATCHED_ABLATION.csv`
* `PARM01_STAGE1_DECISION.json`
* `PARM01_TRAJECTORY_AUDIT.json`
* `PARM01_EVAL_SUMMARIES.json`
* `PARM01_COST_AND_SHA256.json`
* `PARM01_SOURCE_DIFF.md`
* `scripts/parm_common.py`
* `scripts/p01_preflight.py`
* `scripts/p02_gate.py`
* `scripts/p03_run_all.sh`
* `scripts/p04_train.py`
* `scripts/p05_eval.sh`
* `scripts/p05b_identity.py`
* `scripts/p06_eval.py`
* `scripts/p07_deliver.py`
* `scripts/p08_report.py`

SHA256 of every produced artifact is in `PARM01_COST_AND_SHA256.json` (`sha256` and `evals_sha256` blocks, plus `frozen_inputs_sha256` for the frozen inputs and `sha256_after_report` for this report and the source diff, which this script appends after writing them) together with every run's checkpoint hash.

